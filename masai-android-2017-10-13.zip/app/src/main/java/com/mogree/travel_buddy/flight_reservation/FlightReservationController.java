package com.mogree.travel_buddy.flight_reservation;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.gson.Gson;
import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.helper.C;
import com.mogree.travel_buddy.core.model.Reservations;

public class FlightReservationController extends AppCompatActivity implements FlightReservationView.FlightReservationViewListener {
    private FlightReservationView view;
    private Context context;
    private Handler handler;
    private MapView mapView;
    private GoogleMap map;
    private Reservations.FlightReservation flightReservation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.context = this;
        handler = new Handler(Looper.getMainLooper());
        setContentView(R.layout.activity_flight_reservation);
        view = new FlightReservationView(findViewById(android.R.id.content), this, this);
        readFlight(getIntent());
        String departureName = "";
        String arrivalName = "";
        if (flightReservation.getDeparture() != null && flightReservation.getDeparture().getName() != null) {
            departureName = flightReservation.getDeparture().getName();
        }
        if (flightReservation.getArrival() != null && flightReservation.getArrival().getName() != null) {
            arrivalName = flightReservation.getArrival().getName();
        }
        String sourceDestination = departureName.concat(" - ").concat(arrivalName);
        view.setTitle(sourceDestination);
        view.setInfo(flightReservation);
    }

    public void readFlight(Intent intent) {
        String reservationJSON = intent.getStringExtra(C.EXTRA_FLIGHT);
        flightReservation = new Gson().fromJson(reservationJSON, Reservations.FlightReservation.class);
    }

    @Override
    protected void onStop() {
        view.hideProgress();
        super.onStop();
    }

    @Override
    public void onNavigateBack() {
        onBackPressed();
    }

}
