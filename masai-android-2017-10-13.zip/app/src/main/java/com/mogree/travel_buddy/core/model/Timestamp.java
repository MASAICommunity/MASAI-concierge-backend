package com.mogree.travel_buddy.core.model;

/**
 * Created by Semko on 2017-02-21.
 */

public class Timestamp {
    private long $date;

    public long getTimestamp() {
        return $date;
    }

    public void setTimestamp(long $date) {
        this.$date = $date;
    }
}
