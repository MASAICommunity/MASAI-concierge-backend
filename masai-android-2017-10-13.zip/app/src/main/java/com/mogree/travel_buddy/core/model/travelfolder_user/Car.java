package com.mogree.travel_buddy.core.model.travelfolder_user;

import com.mogree.travel_buddy.core.model.Reservations;

import java.util.List;

/**
 * Created by cWahl on 23.08.2017.
 */

public class Car {

	private String bookingClass;
	private String type;
	private List<String> preferences;
	private List<String> extras;
	private List<String> rentalCompanies;
	private List<CarLoyaltyProgram> loyaltyPrograms;
	private String anythingElse;

	//region properties
	public String getBookingClass() {
		return bookingClass;
	}

	public void setBookingClass(String bookingClass) {
		this.bookingClass = bookingClass;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<String> getPreferences() {
		return preferences;
	}

	public void setPreferences(List<String> preferences) {
		this.preferences = preferences;
	}

	public List<String> getExtras() {
		return extras;
	}

	public void setExtras(List<String> extras) {
		this.extras = extras;
	}

	public List<String> getRentalCompanies() {
		return rentalCompanies;
	}

	public void setRentalCompanies(List<String> rentalCompanies) {
		this.rentalCompanies = rentalCompanies;
	}

	public List<CarLoyaltyProgram> getLoyaltyPrograms() {
		return loyaltyPrograms;
	}

	public void setLoyaltyPrograms(List<CarLoyaltyProgram> loyaltyPrograms) {
		this.loyaltyPrograms = loyaltyPrograms;
	}

	public String getAnythingElse() {
		return anythingElse;
	}

	public void setAnythingElse(String anythingElse) {
		this.anythingElse = anythingElse;
	}
	//endregion
}
