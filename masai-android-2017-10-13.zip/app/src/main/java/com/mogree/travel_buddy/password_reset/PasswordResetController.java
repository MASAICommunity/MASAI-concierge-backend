package com.mogree.travel_buddy.password_reset;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.mogree.travel_buddy.R;

public class PasswordResetController extends AppCompatActivity implements PasswordResetView.PasswordResetViewListener {
    PasswordResetView view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_reset);
        view = new PasswordResetView(findViewById(android.R.id.content), this, this);
    }

    @Override
    public void onEmailProvided(String email) {
        view.showProgress();
    }
}