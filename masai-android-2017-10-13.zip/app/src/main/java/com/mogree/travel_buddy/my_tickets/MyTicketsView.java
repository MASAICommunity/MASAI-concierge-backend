package com.mogree.travel_buddy.my_tickets;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.mogree.travel_buddy.R;

/**
 * Created by Semko on 2016-12-05.
 */

public class MyTicketsView {
    private View rootView;
    private MyTicketsViewListener listener;
    private Context context;
    private Handler handler;
    private ListView lvHosts;
    private TextView tvTitle;
    private ImageView ivBack;
    private ProgressDialog progressDialog;

    MyTicketsView(View rootView, Context context, MyTicketsViewListener listener) {
        this.rootView = rootView;
        this.context = context;
        this.listener = listener;
        handler = new Handler(Looper.getMainLooper());
        initViews();
    }

    private void initViews() {
        progressDialog = new ProgressDialog(context, ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(rootView.getContext().getString(R.string.loading_data));
        progressDialog.setCanceledOnTouchOutside(false);
        lvHosts = (ListView) rootView.findViewById(R.id.activity_my_tickets_list_view);
        tvTitle = (TextView) rootView.findViewById(R.id.activity_my_tickets_ala_action_bar_title);
        ivBack = (ImageView) rootView.findViewById(R.id.activity_my_tickets_ala_action_bar_back);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onNavigateBack();
            }
        });
    }

    public void showProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                progressDialog.show();
            }
        });
    }

    public void hideProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (progressDialog != null && progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });
    }

    public void setTitle(final String title) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                tvTitle.setText(title);
            }
        });
    }

    public void setMyTicketsAdapter(MyTicketsAdapter myTicketsAdapter) {
        lvHosts.setAdapter(myTicketsAdapter);
    }

    public interface MyTicketsViewListener {
        void onNavigateBack();
    }
}
