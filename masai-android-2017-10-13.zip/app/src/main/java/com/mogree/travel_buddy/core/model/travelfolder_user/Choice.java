package com.mogree.travel_buddy.core.model.travelfolder_user;

/**
 * Created by cWahl on 25.08.2017.
 */

public class Choice {

	private String value;
	private String text;

	//region properties
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	//endregion
}
