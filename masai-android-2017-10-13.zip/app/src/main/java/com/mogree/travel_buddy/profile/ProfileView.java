package com.mogree.travel_buddy.profile;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.profile.adapter.ViewPagerAdapter;
import com.mogree.travel_buddy.profile.controller.access_privileges.AccessPrivilegesFragment;
import com.mogree.travel_buddy.profile.controller.journey_preferences.JourneyPreferencesFragment;
import com.mogree.travel_buddy.profile.controller.my_data.MyDataController;

public class ProfileView {

	private static final int[] TAB_ICONS = {
			R.drawable.menu_my_data,
			R.drawable.menu_preferences,
			R.drawable.menu_permissions
	};

	private View rootView;
	private ProfileViewListener listener;
	private Context context;
	private WebView travelfolderWebView;
	private ProgressDialog progressDialog;
	private Handler handler;

	private Toolbar toolbar;
	private TabLayout tabLayout;
	private ViewPager viewPager;

	ProfileView(View rootView, Context context, ProfileViewListener listener) {
		this.rootView = rootView;
		this.context = context;
		this.listener = listener;
		handler = new Handler(Looper.getMainLooper());
		initViews();
	}

	private void initViews() {
		progressDialog = new ProgressDialog(context, ProgressDialog.STYLE_SPINNER);
		progressDialog.setMessage(rootView.getContext().getString(R.string.loading_data));
		progressDialog.setCanceledOnTouchOutside(false);

		//travelfolderWebView = (WebView) rootView.findViewById(R.id.profile_web_view);

		toolbar = (Toolbar) rootView.findViewById(R.id.toolbar);
		this.listener.initToolbar(toolbar);
		toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				listener.onBackArrowPressed();
			}
		});

		initTabView();
	}

	private void initTabView() {
		viewPager = (ViewPager) rootView.findViewById(R.id.activity_profile_view_viewpager);
		setupViewPager(viewPager);

		tabLayout = (TabLayout) rootView.findViewById(R.id.activity_profile_view_tabs);
		tabLayout.setupWithViewPager(viewPager);

		setupTabs();
	}

	private void setupTabs() {
		RelativeLayout myDataTab = (RelativeLayout) LayoutInflater.from(context).inflate(R.layout.custom_tab, null);
		TextView myDataTabText = (TextView) myDataTab.findViewById(R.id.custom_tab_text);
		myDataTabText.setText("Meine Daten");
		ImageView myDataTabIcon = (ImageView) myDataTab.findViewById(R.id.custom_tab_icon);
		myDataTabIcon.setImageDrawable(ContextCompat.getDrawable(context, TAB_ICONS[0]));
		tabLayout.getTabAt(0).setCustomView(myDataTab);

		RelativeLayout myPreferencesTab = (RelativeLayout) LayoutInflater.from(context).inflate(R.layout.custom_tab, null);
		TextView myPreferencesTabText = (TextView) myPreferencesTab.findViewById(R.id.custom_tab_text);
		myPreferencesTabText.setText("Reisepräferenzen");
		ImageView myPreferencesTabIcon = (ImageView) myPreferencesTab.findViewById(R.id.custom_tab_icon);
		myPreferencesTabIcon.setImageDrawable(ContextCompat.getDrawable(context, TAB_ICONS[1]));
		tabLayout.getTabAt(1).setCustomView(myPreferencesTab);

		RelativeLayout myPrivilegesTab = (RelativeLayout) LayoutInflater.from(context).inflate(R.layout.custom_tab, null);
		TextView myPrivilegesTabText = (TextView) myPrivilegesTab.findViewById(R.id.custom_tab_text);
		myPrivilegesTabText.setText("Zugriffsrechte");
		ImageView myPrivilegesTabIcon = (ImageView) myPrivilegesTab.findViewById(R.id.custom_tab_icon);
		myPrivilegesTabIcon.setImageDrawable(ContextCompat.getDrawable(context, TAB_ICONS[2]));
		tabLayout.getTabAt(2).setCustomView(myPrivilegesTab);
	}

	private void setupViewPager(ViewPager viewPager) {
		ViewPagerAdapter adapter = new ViewPagerAdapter(((FragmentActivity) context).getSupportFragmentManager());
		adapter.addFragment(new MyDataController(), "Meine Daten");
		adapter.addFragment(new JourneyPreferencesFragment(), "Reisepräferenzen");
		adapter.addFragment(new AccessPrivilegesFragment(), "Zugriffsrechte");
		viewPager.setAdapter(adapter);
	}

	public void showProgress() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				progressDialog.show();
			}
		});
	}

	public void hideProgress() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (progressDialog != null && progressDialog.isShowing()) {
					progressDialog.dismiss();
				}
			}
		});
	}

	interface ProfileViewListener {

		void onBackArrowPressed();

		void onUpdate(String name, String password);

		void initToolbar(Toolbar toolbar);
	}
}