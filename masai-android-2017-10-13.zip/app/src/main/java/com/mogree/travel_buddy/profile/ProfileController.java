package com.mogree.travel_buddy.profile;

import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.profile.controller.access_privileges.AccessPrivilegesFragment;
import com.mogree.travel_buddy.profile.controller.journey_preferences.JourneyPreferencesFragment;
import com.mogree.travel_buddy.profile.controller.my_data.MyDataController;

public class ProfileController extends AppCompatActivity implements ProfileView.ProfileViewListener, MyDataController
		.OnFragmentInteractionListener, JourneyPreferencesFragment.OnFragmentInteractionListener, AccessPrivilegesFragment
		.OnFragmentInteractionListener {

	private ProfileView view;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_profile_view);

		view = new ProfileView(findViewById(android.R.id.content), this, this);
	}

	@Override
	public void onBackArrowPressed() {
		onBackPressed();
	}

	@Override
	public void onUpdate(String name, String password) {
		view.showProgress();
	}

	@Override
	public void initToolbar(Toolbar toolbar) {
		setSupportActionBar(toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
	}

	@Override
	public void onFragmentInteraction(Uri uri) {
		//not used yet
	}
}