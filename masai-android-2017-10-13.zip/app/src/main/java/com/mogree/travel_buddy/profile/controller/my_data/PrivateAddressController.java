package com.mogree.travel_buddy.profile.controller.my_data;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.view.View;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.TravelfolderUserRepo;
import com.mogree.travel_buddy.core.model.travelfolder_user.PrivateAddress;
import com.mogree.travel_buddy.databinding.ActivityMydataPrivateAddressBinding;
import com.mogree.travel_buddy.profile.controller.BaseController;
import com.mogree.travel_buddy.profile.view.PrivateAddressView;
import com.tolstykh.textviewrichdrawable.EditTextRichDrawable;

public class PrivateAddressController extends BaseController implements PrivateAddressView.PrivateAddressViewListener {

	private PrivateAddressView privateAddressView;
	private ActivityMydataPrivateAddressBinding binding;
	private PrivateAddress privateAddress;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		binding = DataBindingUtil.setContentView(this, R.layout.activity_mydata_private_address);

		privateAddressView = new PrivateAddressView(binding.getRoot(), this, this, binding);

		privateAddress = TravelfolderUserRepo.getInstance().getTravelfolderUser().getPrivateAddress();
		if (privateAddress == null) {
			privateAddress = new PrivateAddress();
		}
		privateAddressView.setContent(privateAddress);
	}

	@Override
	public void updatePrivateAddress(View view) {
		switch (view.getId()) {
		case R.id.activity_mydata_private_address_line1:
			privateAddress.setAddressLine1(((EditTextRichDrawable) view).getText().toString());
			break;
		case R.id.activity_mydata_private_address_line2:
			privateAddress.setAddressLine2(((EditTextRichDrawable) view).getText().toString());
			break;
		case R.id.activity_mydata_private_address_city:
			privateAddress.setCity(((EditTextRichDrawable) view).getText().toString());
			break;
		case R.id.activity_mydata_private_address_state:
			privateAddress.setState(((EditTextRichDrawable) view).getText().toString());
			break;
		case R.id.activity_mydata_private_address_zip:
			privateAddress.setZip(((EditTextRichDrawable) view).getText().toString());
			break;
		case R.id.activity_mydata_private_address_country:
			privateAddress.setCountry(((EditTextRichDrawable) view).getText().toString());
			break;
		default:
			break;
		}

		TravelfolderUserRepo.getInstance().getTravelfolderUser().setPrivateAddress(privateAddress);
		privateAddressView.setContent(privateAddress);
	}

	@Override
	public void onBackArrowPressed() {
		onBackPressed();
	}
}
