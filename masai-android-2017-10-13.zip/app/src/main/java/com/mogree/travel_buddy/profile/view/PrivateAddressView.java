package com.mogree.travel_buddy.profile.view;

import android.content.Context;
import android.view.View;

import com.mogree.travel_buddy.core.model.travelfolder_user.PrivateAddress;
import com.mogree.travel_buddy.databinding.ActivityMydataPrivateAddressBinding;

/**
 * Created by cWahl on 25.08.2017.
 */

public class PrivateAddressView extends BaseView implements View.OnFocusChangeListener {

	private PrivateAddressView.PrivateAddressViewListener listener;
	private ActivityMydataPrivateAddressBinding binding;

	public PrivateAddressView(View rootView, Context context, PrivateAddressView.PrivateAddressViewListener listener,
	                          ActivityMydataPrivateAddressBinding binding) {
		super(rootView, context);
		this.listener = listener;
		this.binding = binding;
		setOnFocusChangedListener();
	}

	public void setOnFocusChangedListener() {
		binding.activityMydataPrivateAddressLine1.setOnFocusChangeListener(this);
		binding.activityMydataPrivateAddressLine2.setOnFocusChangeListener(this);
		binding.activityMydataPrivateAddressCity.setOnFocusChangeListener(this);
		binding.activityMydataPrivateAddressState.setOnFocusChangeListener(this);
		binding.activityMydataPrivateAddressZip.setOnFocusChangeListener(this);
		binding.activityMydataPrivateAddressCountry.setOnFocusChangeListener(this);
	}

	public void setContent(PrivateAddress privateAddress) {
		if (privateAddress.getAddressLine1() != null) {
			binding.activityMydataPrivateAddressLine1.setText(privateAddress.getAddressLine1());
		}
		if (privateAddress.getAddressLine2() != null) {
			binding.activityMydataPrivateAddressLine2.setText(privateAddress.getAddressLine2());
		}
		if (privateAddress.getCity() != null) {
			binding.activityMydataPrivateAddressCity.setText(privateAddress.getCity());
		}
		if (privateAddress.getState() != null) {
			binding.activityMydataPrivateAddressState.setText(privateAddress.getState());
		}
		if (privateAddress.getZip() != null) {
			binding.activityMydataPrivateAddressZip.setText(privateAddress.getZip());
		}
		if (privateAddress.getCountry() != null) {
			binding.activityMydataPrivateAddressCountry.setText(privateAddress.getCountry());
		}
	}

	@Override
	public void onFocusChange(View view, boolean isFocused) {
		super.onFocusChange(view, isFocused);

		if (!isFocused) {
			listener.updatePrivateAddress(view);
		}
	}

	public interface PrivateAddressViewListener {

		void updatePrivateAddress(View view);

		void onBackArrowPressed();
	}
}
