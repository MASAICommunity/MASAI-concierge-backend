package com.mogree.travel_buddy.profile.controller.my_data;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.view.View;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.TravelfolderUserRepo;
import com.mogree.travel_buddy.core.model.travelfolder_user.ContactInfo;
import com.mogree.travel_buddy.databinding.ActivityMydataContactInfoBinding;
import com.mogree.travel_buddy.profile.controller.BaseController;
import com.mogree.travel_buddy.profile.view.ContactInfoView;
import com.tolstykh.textviewrichdrawable.EditTextRichDrawable;

public class ContactInfoController extends BaseController implements ContactInfoView.ContactInfoViewListener {

	private ContactInfoView contactInfoView;
	private ActivityMydataContactInfoBinding binding;
	private ContactInfo contactInfo;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		binding = DataBindingUtil.setContentView(this, R.layout.activity_mydata_contact_info);
		contactInfoView = new ContactInfoView(binding.getRoot(), this, this, binding);

		contactInfo = TravelfolderUserRepo.getInstance().getTravelfolderUser().getContactInfo();
		if (contactInfo == null) {
			contactInfo = new ContactInfo();
		}
		contactInfoView.setContent(contactInfo);
	}

	@Override
	public void updateContactInfo(View view) {
		switch (view.getId()) {
		case R.id.activity_mydata_contact_info_email:
			contactInfo.setPrimaryEmail(((EditTextRichDrawable) view).getText().toString());
			break;
		case R.id.activity_mydata_contact_info_phone_number:
			contactInfo.setPrimaryPhone(((EditTextRichDrawable) view).getText().toString());
			break;
		default:
			break;
		}

		TravelfolderUserRepo.getInstance().getTravelfolderUser().setContactInfo(contactInfo);
		contactInfoView.setContent(contactInfo);
	}
}
