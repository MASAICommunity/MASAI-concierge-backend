package com.mogree.travel_buddy.profile.viewHolder;

import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.mogree.travel_buddy.R;
import com.tolstykh.textviewrichdrawable.TextViewRichDrawable;

/**
 * Created by tom on 25.08.17.
 */

public class JourneyPreferencesMenuViewHolder extends RecyclerView.ViewHolder {

	public TextViewRichDrawable textView;

	public JourneyPreferencesMenuViewHolder(View itemView) {
		super(itemView);

		textView = (TextViewRichDrawable) itemView.findViewById(R.id.fragment_preferences_menu_textfield);
	}
}
