package com.mogree.travel_buddy.profile.view;

import android.content.Context;
import android.view.View;

import com.mogree.travel_buddy.core.model.travelfolder_user.ContactInfo;
import com.mogree.travel_buddy.databinding.ActivityMydataContactInfoBinding;

/**
 * Created by cWahl on 25.08.2017.
 */

public class ContactInfoView extends BaseView {

	private ContactInfoView.ContactInfoViewListener listener;
	private ActivityMydataContactInfoBinding binding;

	public ContactInfoView(View rootView, Context context, ContactInfoView.ContactInfoViewListener listener,
	                       ActivityMydataContactInfoBinding binding) {
		super(rootView, context);

		this.binding = binding;
		this.listener = listener;
		setOnFocusChangedListener();
	}

	public void setOnFocusChangedListener() {
		binding.activityMydataContactInfoEmail.setOnFocusChangeListener(this);
		binding.activityMydataContactInfoPhoneNumber.setOnFocusChangeListener(this);
	}

	public void setContent(ContactInfo contactInfo) {
		if (contactInfo.getPrimaryEmail() != null) {
			binding.activityMydataContactInfoEmail.setText(contactInfo.getPrimaryEmail());
		}
		if (contactInfo.getPrimaryPhone() != null) {
			binding.activityMydataContactInfoPhoneNumber.setText(contactInfo.getPrimaryPhone());
		}
	}

	@Override
	public void onFocusChange(View view, boolean isFocused) {
		super.onFocusChange(view, isFocused);

		if (!isFocused) {
			listener.updateContactInfo(view);
		}
	}

	public interface ContactInfoViewListener {

		void updateContactInfo(View view);

		void onBackArrowPressed();
	}
}
