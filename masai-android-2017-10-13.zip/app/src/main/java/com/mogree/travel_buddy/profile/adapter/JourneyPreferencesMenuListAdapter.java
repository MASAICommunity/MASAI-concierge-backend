package com.mogree.travel_buddy.profile.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.profile.viewHolder.JourneyPreferencesMenuViewHolder;

/**
 * Created by tom on 25.08.17.
 */

public class JourneyPreferencesMenuListAdapter extends  RecyclerView.Adapter<JourneyPreferencesMenuViewHolder> {

	String[] itemNames;
	int[] itemImages;

	Context context;
	LayoutInflater inflater;

	public JourneyPreferencesMenuListAdapter(Context context) {
		this.context=context;
		inflater=LayoutInflater.from(context);

		itemNames = new String[]{
				this.context.getResources().getString(R.string.passport),
				this.context.getResources().getString(R.string.esta),
				this.context.getResources().getString(R.string.hotel),
				this.context.getResources().getString(R.string.flights),
				this.context.getResources().getString(R.string.rental_car),
				this.context.getResources().getString(R.string.train)};

		itemImages = new int[]{
				R.drawable.travel,
				R.drawable.ic_train,
				R.drawable.ic_train,
				R.drawable.ic_train,
				R.drawable.ic_airplanemode_active,
				R.drawable.ic_profile_train};
	}
	@Override
	public JourneyPreferencesMenuViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
		View v=inflater.inflate(R.layout.item_preferences_menu
				, parent, false);

		JourneyPreferencesMenuViewHolder viewHolder = new JourneyPreferencesMenuViewHolder(v);
		return viewHolder;
	}

	@Override
	public void onBindViewHolder(JourneyPreferencesMenuViewHolder holder, int position) {

		holder.textView.setText(itemNames[position]);

		holder.textView.setDrawableStartVectorId(itemImages[position]);
	}

	View.OnClickListener clickListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {

			JourneyPreferencesMenuViewHolder vholder = (JourneyPreferencesMenuViewHolder) v.getTag();
			int position = vholder.getPosition();

//			Toast.makeText(context,"This is position "+position,Toast.LENGTH_LONG ).show();

		}
	};



	@Override
	public int getItemCount() {
		return itemNames.length;
	}
}
