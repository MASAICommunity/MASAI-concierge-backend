package com.mogree.travel_buddy.core.communication;

import android.content.Context;

import com.google.gson.Gson;
import com.mogree.travel_buddy.core.helper.C;
import com.mogree.travel_buddy.core.helper.PrefsHelper;
import com.mogree.travel_buddy.core.helper.RealmHelper;
import com.mogree.travel_buddy.core.model.Host;
import com.mogree.travel_buddy.core.model.User;

import java.util.ArrayList;
import java.util.List;

import io.realm.RealmChangeListener;
import io.realm.RealmResults;

/**
 * Created by Semko on 2016-12-02.
 */

public class ConnectionManager {
    private static ConnectionManager instance;
    private List<HostConnection> hostConnections = new ArrayList<>();
    private User user;
    private List<Host> hostList = new ArrayList<>();
    private String gcmToken;
    private static boolean shouldShowReconnectInfo = false;


    private RealmChangeListener<RealmResults<Host>> hostConnectionListChangeListener = new RealmChangeListener<RealmResults<Host>>() {
        @Override
        public void onChange(RealmResults<Host> element) {

        }
    };

    protected ConnectionManager() {
        retrieveUsername();
        loadHostConnectionsFromDB();
        demoHostList();
    }

    public static ConnectionManager getInstance() {
        if (instance == null) {
            instance = new ConnectionManager();
        }
        return instance;
    }

    public static boolean isShouldShowInfoReconnecting() {
        return shouldShowReconnectInfo;
    }

    public static void setShouldShowInfoReconnecting(boolean shouldShowReconnectInfo) {
        ConnectionManager.shouldShowReconnectInfo = shouldShowReconnectInfo;
    }

    public int getHostPosition(int pos) {
        if (hostList.size() > pos) {
            String hostToAddUrl = hostList.get(pos).getHostUrl();
            for (HostConnection connection : hostConnections) {
                if (connection.getHost().getHostUrl().equals(hostToAddUrl)) {
                    return connection.getConnectionPositionOnList();
                }
            }
        }
        return -1;
    }

    private void loadHostConnectionsFromDB() {
        for (Host host : RealmHelper.getInstance().getHostConnectionListListener(hostConnectionListChangeListener)) {
            addHostToList(host);
        }
    }

    public List<HostConnection> getHostConnectionList() {
        return hostConnections;
    }

    public HostConnection getHostConnectionForPos(int pos) {
        if (pos < hostConnections.size()) {
            return hostConnections.get(pos);
        }
        return null;
    }

    public List<Host> getHostList() {
        return hostList;
    }

    private void retrieveUsername() {
        if (PrefsHelper.getInstance() != null && PrefsHelper.getInstance().contains(C.PREFERENCES_KEY_USER)) {
            user = new Gson().fromJson(PrefsHelper.getInstance().getString(C.PREFERENCES_KEY_USER), User.class);
            if (user != null) {
                C.L("user retrieved + " + user.getEmail() + ", " + user.getPassword() + ", " + user.getUsername());
            }
        }
    }

    private void demoHostList() {

        Host fiveLvlUpHost = new Host();
        fiveLvlUpHost.setHostUrl(""); //rocket chat server
        fiveLvlUpHost.setHostRocketChatApiUrl(""); // rocket chat api
        fiveLvlUpHost.setHumanName("DB Concierge");

        hostList.add(fiveLvlUpHost);

    }

    public int addConnection(Context context, final int position, boolean isConnected, final IConnectListener listener) {
        Host realmHost = RealmHelper.getInstance().addHost(hostList.get(position));
        final int connectionPos = addHostToList(realmHost);
        if (isConnected) {
            connectToAll(context, new IConnectListener() {
                @Override
                public void onDisconnected(int pos) {
                    if (connectionPos == pos) {
                        removeConnection(position);
                        listener.onDisconnected(pos);
                    }
                }

                @Override
                public void onConnectedAndLoggedIn(final int pos) {
                    if (connectionPos == pos) {
                        listener.onConnectedAndLoggedIn(pos);
                    }
                }

                @Override
                public void onBadPassword(int pos) {
                    if (connectionPos == pos) {
                        removeConnection(position);
                        listener.onBadPassword(pos);
                    }
                }

                @Override
                public void onUserNotFound(int pos) {
                    if (connectionPos == pos) {
                        removeConnection(position);
                        listener.onUserNotFound(pos);
                    }
                }

                @Override
                public void onNoUsername(int pos) {
                    if (connectionPos == pos) {
                        removeConnection(position);
                        listener.onNoUsername(pos);
                    }
                }

                @Override
                public void onNewMessage(int pos) {
                    if (connectionPos == pos) {
                        listener.onNewMessage(pos);
                    }
                }

                @Override
                public void onConnectivityError(int pos) {
                    if (connectionPos == pos) {
                        removeConnection(position);
                        listener.onConnectivityError(pos);
                    }
                }
            });
        }
        return connectionPos;
    }

    public void removeConnection(int position) {
        if (hostConnections.size() > position) {
            RealmHelper.getInstance().removeHost(hostConnections.get(position).getHost().getId());
            hostConnections.remove(position);
        }
    }

    public void removeAll() {
        while (hostConnections.size() > 0) {
            removeConnection(0);
        }
        hostConnections = new ArrayList<>();
        hostList.clear();
        setUser(null);
    }

    public static void clear() {
        instance = null;
    }

    public void connectToAll(Context context, IConnectListener listener) {
        for (int co0 = 0; co0 < hostConnections.size(); ++co0) {
            connectTo(context, co0, listener);
        }
    }

    public void connectTo(Context context, final int pos, final IConnectListener listener) {
        if (pos < hostConnections.size()) {
            HostConnection connection = hostConnections.get(pos);
            connection.connectIfDisconnectedAndSetHostListener(context, new HostConnection.IHostConnectionCallback() {
                @Override
                public void onDisconnected() {
                    listener.onDisconnected(pos);
                }

                @Override
                public void onConnectedAndLoggedIn() {
                    listener.onConnectedAndLoggedIn(pos);
                }

                public void onNewMessage() {
                    listener.onNewMessage(pos);
                }

                @Override
                public void onConnectivityError() {
                    listener.onConnectivityError(pos);
                }
            });
        }
    }

    private int addHostToList(Host host) {
        for (int co0 = 0; co0 < hostConnections.size(); ++co0) {
            if (hostConnections.get(co0).getHost().getHostUrl().equals(host.getHostUrl())) {
                return co0;
            }
        }
        final HostConnection connection = new HostConnection(host, user);
        connection.setConnectionPositionOnList(hostConnections.size());
        hostConnections.add(connection);
        return hostConnections.size() - 1;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
        String userJ = new Gson().toJson(user);
        for (HostConnection hostConnection : hostConnections) {
            hostConnection.setUser(user);
        }
        if (user == null) {
            PrefsHelper.getInstance().setString(C.PREFERENCES_KEY_USER, "");
        } else {
            PrefsHelper.getInstance().setString(C.PREFERENCES_KEY_USER, userJ);
        }
    }

    public String getGcmToken() {
        return gcmToken;
    }

    public void setGcmToken(String gcmToken) {
        this.gcmToken = gcmToken;
    }

    public interface IConnectListener {
        void onDisconnected(int pos);

        void onConnectedAndLoggedIn(int pos);

        void onBadPassword(int pos);

        void onUserNotFound(int pos);

        void onNoUsername(int pos);

        void onNewMessage(int pos);

        void onConnectivityError(int pos);
    }
}
