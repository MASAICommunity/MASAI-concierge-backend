package com.mogree.travel_buddy.core.helper;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.mogree.travel_buddy.core.model.travelfolder_user.BillingAddress;
import com.mogree.travel_buddy.core.model.travelfolder_user.Car;
import com.mogree.travel_buddy.core.model.travelfolder_user.ContactInfo;
import com.mogree.travel_buddy.core.model.travelfolder_user.Esta;
import com.mogree.travel_buddy.core.model.travelfolder_user.Flight;
import com.mogree.travel_buddy.core.model.travelfolder_user.Hotel;
import com.mogree.travel_buddy.core.model.travelfolder_user.JourneyPreferences;
import com.mogree.travel_buddy.core.model.travelfolder_user.Passport;
import com.mogree.travel_buddy.core.model.travelfolder_user.PersonalData;
import com.mogree.travel_buddy.core.model.travelfolder_user.PrivateAddress;
import com.mogree.travel_buddy.core.model.travelfolder_user.PrivatePayment;
import com.mogree.travel_buddy.core.model.travelfolder_user.Train;
import com.mogree.travel_buddy.core.model.travelfolder_user.TravelfolderUser;

import java.lang.reflect.Type;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import static com.mogree.travel_buddy.core.helper.DeserializerHelper.getMapObject;
import static com.mogree.travel_buddy.core.helper.DeserializerHelper.getNumberField;
import static com.mogree.travel_buddy.core.helper.DeserializerHelper.getStringField;

/**
 * Created by cWahl on 22.08.2017.
 */

public class TravelfolderUserConverter implements JsonSerializer<TravelfolderUser>, JsonDeserializer<TravelfolderUser> {

	private static final String ESCAPED_QUOTE = "\"";

	@Override
	public JsonElement serialize(TravelfolderUser src, Type typeOfSrc, JsonSerializationContext context) {
		Map<String, String> personal = new LinkedHashMap<String, String>();
		personal.put("title", "new_title");
		personal.put("first_name", "new first");
		personal.put("middle_name", "new middle");

		return null;
	}

	@Override
	public TravelfolderUser deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
		DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
		final JsonObject jsonObject = json.getAsJsonObject().get("Items").getAsJsonArray().get(0).getAsJsonObject();

		TravelfolderUser user = new TravelfolderUser();
		user.setUserId(getStringField(jsonObject, "UserId"));
		user.setIdentitySource(getStringField(jsonObject, "IdentitySource"));

		String created = getNumberField(jsonObject, "created");
		if (created != null) {
			user.setCreated(new Date(Long.parseLong(created)));
		}
		String modified = getNumberField(jsonObject, "modified");
		if (modified != null) {
			user.setModified(new Date(Long.parseLong(modified)));
		}

		//region esta
		JsonObject jsonEsta = getMapObject(jsonObject, "esta");
		if (jsonEsta != null) {
			Esta esta = new Esta();
			String validUntil = getStringField(jsonEsta, "valid_until");
			String applicationNumber = getStringField(jsonEsta, "application_number");
			if (validUntil != null) {
				try {
					esta.setValidUntil(dateFormat.parse(validUntil));
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
			esta.setApplicationNumber(applicationNumber);
			user.setEsta(esta);
		}
		//endregion

		//region billing address
		JsonObject jsonBillingAddress = getMapObject(jsonObject, "address_billing");
		BillingAddress billingAddress = new BillingAddress();
		if (jsonBillingAddress != null) {
			billingAddress.setZip(getStringField(jsonBillingAddress, "zip"));
			billingAddress.setCountry(getStringField(jsonBillingAddress, "country"));
			billingAddress.setCity(getStringField(jsonBillingAddress, "city"));
			billingAddress.setCompanyName(getStringField(jsonBillingAddress, "company_name"));
			billingAddress.setAddressLine1(getStringField(jsonBillingAddress, "address_line_1"));
			billingAddress.setAddressLine2(getStringField(jsonBillingAddress, "address_line_2"));
			billingAddress.setState(getStringField(jsonBillingAddress, "state"));
			billingAddress.setVat(getStringField(jsonBillingAddress, "vat"));
			user.setBillingAddress(billingAddress);
		}
		//endregion

		//region private payment
		JsonObject jsonPrivatePayment = getMapObject(jsonObject, "private_payment");
		if (jsonPrivatePayment != null) {
			PrivatePayment privatePayment = new PrivatePayment();
			privatePayment.setCreditCard(getStringField(jsonPrivatePayment, "credit_card"));
			privatePayment.setDefaultPaymentMethod(getStringField(jsonPrivatePayment, "default_payment_method"));
			user.setPrivatePayment(privatePayment);
		}
		//endregion

		//region contact
		JsonObject jsonContactInfo = getMapObject(jsonObject, "contact");
		if (jsonContactInfo != null) {
			ContactInfo contactInfo = new ContactInfo();
			contactInfo.setPrimaryEmail(getStringField(jsonContactInfo, "primary_email"));
			contactInfo.setPrimaryPhone(getStringField(jsonContactInfo, "primary_phone"));
			user.setContactInfo(contactInfo);
		}
		//endregion

		//region passport
		JsonObject jsonPassport = getMapObject(jsonObject, "passport");
		if (jsonPassport != null) {
			Passport passport = new Passport();
			passport.setCountry(getStringField(jsonPassport, "country"));
			passport.setNumber(getStringField(jsonPassport, "number"));
			passport.setCity(getStringField(jsonPassport, "city"));
			try {
				String expiry = getStringField(jsonPassport, "expiry");
				String dateIssued = getStringField(jsonPassport, "date_issued");
				if (expiry != null) {
					passport.setExpiry(dateFormat.parse(expiry));
				}
				if (dateIssued != null) {
					passport.setDateIssued(dateFormat.parse(dateIssued));
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}
			user.setPassport(passport);
		}
		//endregion

		//region journey preferences
		JsonObject jsonPreferences = getMapObject(jsonObject, "preference");
		if (jsonPreferences != null) {
			Hotel hotel = JourneyPreferencesDeserializerHelper.deserializeHotel(jsonPreferences);
			Flight flight = JourneyPreferencesDeserializerHelper.deserializeFlight(jsonPreferences);
			Car car = JourneyPreferencesDeserializerHelper.deserializeCar(jsonPreferences);
			Train train = JourneyPreferencesDeserializerHelper.deserilizeTrain(jsonPreferences);
			JourneyPreferences journeyPreferences = new JourneyPreferences();
			journeyPreferences.setHotel(hotel);
			journeyPreferences.setFlights(flight);
			journeyPreferences.setCar(car);
			journeyPreferences.setTrain(train);
			user.setJourneyPreferences(journeyPreferences);
		}
		//endregion

		//region private address
		JsonObject jsonPrivateAddress = getMapObject(jsonObject, "address_private");
		if (jsonPrivateAddress != null) {
			PrivateAddress privateAddress = new PrivateAddress();
			privateAddress.setZip(getStringField(jsonPrivateAddress, "zip"));
			privateAddress.setAddressLine1(getStringField(jsonPrivateAddress, "address_line_1"));
			privateAddress.setCountry(getStringField(jsonPrivateAddress, "country"));
			privateAddress.setAddressLine2(getStringField(jsonPrivateAddress, "address_line_2"));
			privateAddress.setState(getStringField(jsonPrivateAddress, "state"));
			privateAddress.setCity(getStringField(jsonPrivateAddress, "city"));
			user.setPrivateAddress(privateAddress);
		}
		//endregion

		//region personal data
		JsonObject jsonPersonalData = getMapObject(jsonObject, "personal");
		if (jsonPersonalData != null) {
			PersonalData personalData = new PersonalData();
			personalData.setTitle(getStringField(jsonPersonalData, "title"));
			personalData.setFirstname(getStringField(jsonPersonalData, "first_name"));
			personalData.setMiddlename(getStringField(jsonPersonalData, "middle_name"));
			personalData.setLastname(getStringField(jsonPersonalData, "last_name"));
			personalData.setNationality(getStringField(jsonPersonalData, "nationality"));
			personalData.setBirthdate(getStringField(jsonPersonalData, "birth_date"));
			user.setPersonalData(personalData);
		}
		//endregion

		return user;
	}
}
