package com.mogree.travel_buddy.service;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.google.gson.Gson;
import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.conversations.ConversationsController;
import com.mogree.travel_buddy.core.helper.C;

import java.util.Map;

public class MyFirebaseMessagingService extends FirebaseMessagingService {
    private String roomId = "";
    private String title = "";
    private String message = "";

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        C.L("From: " + remoteMessage.getFrom());

        if (remoteMessage == null)
            return;

        for (Map.Entry<String, String> entry : remoteMessage.getData().entrySet()) {
            C.L(entry.getKey() + " : " + entry.getValue());
            if (entry.getKey().contains("json")) {
                NotificationRocketChatModel notificationRocketChatModel = new Gson().fromJson(entry.getValue(), NotificationRocketChatModel.class);
                C.L("ROOM ID" + notificationRocketChatModel.getRid());
            }
            if (entry.getKey().contains("message")) {
                message = entry.getValue();
            }
            if (entry.getKey().contains("title")) {
                title = entry.getValue();
            }
        }
        notifyOfMessage();
    }

    class NotificationRocketChatModel {
        private String rid;

        public String getRid() {
            return rid;
        }
    }

    private void notifyOfMessage() {
        Intent intent = new Intent(this, ConversationsController.class);
        intent.putExtra(C.EXTRA_ROOM_ID, roomId);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, (int) System.currentTimeMillis(), intent, 0);
        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(this)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle(title)
                        .setContentIntent(pendingIntent)
                        .setContentText(message);
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification notification = mBuilder.build();
        notification.flags |= Notification.FLAG_AUTO_CANCEL;
        mNotificationManager.notify(001, notification);
    }
}