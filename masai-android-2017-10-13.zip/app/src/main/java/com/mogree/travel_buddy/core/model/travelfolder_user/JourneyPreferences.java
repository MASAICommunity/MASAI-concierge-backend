package com.mogree.travel_buddy.core.model.travelfolder_user;

/**
 * Created by cWahl on 23.08.2017.
 */

public class JourneyPreferences {

	private Flight flights;
	private Hotel hotel;
	private Car car;
	private Train train;

	//region properties
	public Flight getFlights() {
		return flights;
	}

	public void setFlights(Flight flights) {
		this.flights = flights;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}

	public Train getTrain() {
		return train;
	}

	public void setTrain(Train train) {
		this.train = train;
	}
	//endregion
}
