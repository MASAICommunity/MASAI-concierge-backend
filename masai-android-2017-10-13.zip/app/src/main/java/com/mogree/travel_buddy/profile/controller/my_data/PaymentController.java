package com.mogree.travel_buddy.profile.controller.my_data;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.mogree.travel_buddy.R;

public class PaymentController extends AppCompatActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_mydata_payment);

		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
	}
}
