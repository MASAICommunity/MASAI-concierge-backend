package com.mogree.travel_buddy.core.model;

/**
 * Created by Semko on 2017-02-23.
 */

public class MeteorRoomId {
    private String rid;

    public String getRid() {
        return rid;
    }

    public void setRid(String rid) {
        this.rid = rid;
    }
}
