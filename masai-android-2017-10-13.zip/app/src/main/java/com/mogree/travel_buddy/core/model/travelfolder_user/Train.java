package com.mogree.travel_buddy.core.model.travelfolder_user;

import java.util.List;

/**
 * Created by cWahl on 23.08.2017.
 */

public class Train {

	private String anythingElse;
	private List<TrainLoyaltyProgram> loyaltyPrograms;

	//region properties
	public String getAnythingElse() {
		return anythingElse;
	}

	public void setAnythingElse(String anythingElse) {
		this.anythingElse = anythingElse;
	}

	public List<TrainLoyaltyProgram> getLoyaltyPrograms() {
		return loyaltyPrograms;
	}

	public void setLoyaltyPrograms(List<TrainLoyaltyProgram> loyaltyPrograms) {
		this.loyaltyPrograms = loyaltyPrograms;
	}
	//endregion
}
