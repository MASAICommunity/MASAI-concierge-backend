package com.mogree.travel_buddy.profile.controller;

import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

/**
 * Created by cWahl on 25.08.2017.
 */

public class BaseController extends AppCompatActivity {

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			onBackPressed();
			return true;
		}
		return false;
	}

	public void onBackArrowPressed() {
		onBackPressed();
	}
}
