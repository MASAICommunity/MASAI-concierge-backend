package com.mogree.travel_buddy.core.model;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Created by Semko on 2016-12-01.
 */

public class Host extends RealmObject {
    @PrimaryKey
    private long id;
    private String hostUrl;
    private String hostRocketChatApiUrl;
    private String humanName;
    private String userLoginToken;
    private String roomId;
    private String userId;
    private long expires;

    public String getHumanName() {
        return humanName;
    }

    public void setHumanName(String humanName) {
        this.humanName = humanName;
    }

    public String getHostUrl() {
        return hostUrl;
    }

    public void setHostUrl(String hostUrl) {
        this.hostUrl = hostUrl;
    }

    public String getLoginToken() {
        return userLoginToken;
    }

    public void setUserLoginToken(String userLoginToken) {
        this.userLoginToken = userLoginToken;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getRoomId() {
        return roomId;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }

    public String getHostRocketChatApiUrl() {
        return hostRocketChatApiUrl;
    }

    public void setHostRocketChatApiUrl(String hostRocketChatApiUrl) {
        this.hostRocketChatApiUrl = hostRocketChatApiUrl;
    }

    public long getExpires() {
        return expires;
    }

    public String getLiveChatUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
