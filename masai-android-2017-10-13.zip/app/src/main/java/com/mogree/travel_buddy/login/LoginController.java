package com.mogree.travel_buddy.login;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;

import com.auth0.android.provider.WebAuthProvider;
import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.communication.Auth0Helper;
import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.helper.PrefsHelper;
import com.mogree.travel_buddy.password_reset.PasswordResetController;
import com.mogree.travel_buddy.register.RegisterController;

public class LoginController extends AppCompatActivity implements LoginView.LoginViewListener {
    private LoginView view;
    private boolean successfullyLoggedIn = false;
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        view = new LoginView(findViewById(android.R.id.content), this, this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        PrefsHelper.init(this);
        if (ConnectionManager.getInstance().getHostConnectionList().size() > 0) {
            finish();
        }
    }

    @Override
    protected void onPause() {
        if (!successfullyLoggedIn) {
            ConnectionManager.getInstance().setUser(null);
            while (ConnectionManager.getInstance().getHostConnectionList().size() > 0) {
                ConnectionManager.getInstance().removeConnection(0);
            }
        }
        super.onPause();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        if (WebAuthProvider.resume(intent)) {
            return;
        }
        super.onNewIntent(intent);
    }

    private void login() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                view.showProgress();
                ConnectionManager.getInstance().addConnection(LoginController.this, 0, true, new ConnectionManager.IConnectListener() {
                    @Override
                    public void onDisconnected(int pos) {
                        view.showOkDialog(R.string.connection_restore);
                        view.hideProgress();
                    }

                    @Override
                    public void onConnectedAndLoggedIn(int pos) {
                        successfullyLoggedIn = true;
                        view.hideProgress();
                        finish();
                    }

                    @Override
                    public void onBadPassword(int pos) {
                        view.showOkDialog(R.string.incorrect_password);
                        view.hideProgress();
                    }

                    @Override
                    public void onUserNotFound(int pos) {
                        view.showOkDialog(R.string.user_does_not_exist);
                        view.hideProgress();
                    }

                    @Override
                    public void onNoUsername(int pos) {
                        view.showOkDialog(R.string.user_does_not_exist);
                        view.hideProgress();
                    }

                    @Override
                    public void onNewMessage(int pos) {

                    }

                    @Override
                    public void onConnectivityError(int pos) {
                        view.showOkDialog(R.string.connection_restore);
                        view.hideProgress();
                    }
                });
            }
        });
    }

    @Override
    public void onRegisterClicked() {
        startActivity(new Intent(this, RegisterController.class));
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        moveTaskToBack(true);
    }

    @Override
    public void onPasswordResetClicked() {
        startActivity(new Intent(this, PasswordResetController.class));
    }

    @Override
    public void onContinueLogin(String email, String username, String password) {
        Auth0Helper.getInstance().logIn(email, password, username, loginCallback);
    }

    private Auth0Helper.ILogIn loginCallback = new Auth0Helper.ILogIn() {
        @Override
        public void onLoggedIn() {
            login();
        }

        @Override
        public void onLoginError() {
            view.showOkDialog(R.string.connection_restore);
        }

        @Override
        public void onBadCredentials() {
            view.showOkDialog(R.string.bad_user_or_pass);
        }
    };

    @Override
    public void onLogInWithFacebook() {
        Auth0Helper.getInstance().logInWithFacebook(this, loginCallback);
    }

    @Override
    public void onLogInWithGoogle() {
        Auth0Helper.getInstance().logInWithGoogle(this, loginCallback);
    }

    @Override
    public void onLogInWithTwitter() {
        Auth0Helper.getInstance().logInWithTwitter(this, loginCallback);
    }

    @Override
    public void onLogInWithLinkedIn() {
        Auth0Helper.getInstance().logInWithLinkedIn(this, loginCallback);
    }
}