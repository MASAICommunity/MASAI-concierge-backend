package com.mogree.travel_buddy.core;

import com.mogree.travel_buddy.BuildConfig;
import com.mogree.travel_buddy.core.model.travelfolder_user.TravelfolderUser;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;

/**
 * Created by cWahl on 21.08.2017.
 */

public class BackendManager {

	private static BackendManager instance = null;
	private static Retrofit retrofit = null;
	private OkHttpClient client;
	private static final String BASE_URL = ""; //aws api gateway url
	public static final String AUTHORIZATION_BEARER_PREFIX = "Bearer ";
	private BackendInterface backendService;

	private BackendManager() {
		buildRetrofit();
	}

	public static BackendManager getInstance() {
		if (instance == null) {
			instance = new BackendManager();
		}

		return instance;
	}

	private void buildRetrofit() {
		HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
		loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
		OkHttpClient.Builder okHttpBuilder = new OkHttpClient.Builder();

		if (BuildConfig.DEBUG) {
			okHttpBuilder.addInterceptor(loggingInterceptor);
		}
		client = okHttpBuilder.build();

		retrofit = new Retrofit.Builder().baseUrl(BASE_URL)
				.addConverterFactory(GsonConverterFactory.create())
				.client(client)
				.build();

		backendService = retrofit.create(BackendInterface.class);
	}

	public BackendInterface getBackendService() {
		return this.backendService;
	}

	public interface BackendInterface {

		@POST("/latest/users/me/profile")
		Call<TravelfolderUser> updateTravelfolderUser(@Body TravelfolderUser user, @Header("Authorization") String authHeader);

		@GET("/latest/users/me/profile")
		Call<ResponseBody> getTravelfolderUser(@Header("Authorization") String authHeader);

		@GET("/latest/choices")
		Call<ResponseBody> getChoices();
	}
}