package com.mogree.travel_buddy.core.model.travelfolder_user;

import java.util.List;

/**
 * Created by cWahl on 25.08.2017.
 */

public class Choices {

	private String dataKey;
	private String text;
	private List<Choice> choices;

	//region properties
	public String getDataKey() {
		return dataKey;
	}

	public void setDataKey(String dataKey) {
		this.dataKey = dataKey;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public List<Choice> getChoices() {
		return choices;
	}

	public void setChoices(List<Choice> choices) {
		this.choices = choices;
	}
	//endregion
}
