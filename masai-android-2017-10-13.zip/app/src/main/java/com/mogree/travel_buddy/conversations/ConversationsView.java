package com.mogree.travel_buddy.conversations;

import android.os.Handler;
import android.os.Looper;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.helper.TimeHelper;

class ConversationsView {
    private View rootView;
    private ConversationsController activity;
    private ConversationsViewListener listener;
    private ListView lvHostConnection;
    private FloatingActionButton fabGoToAddHostController;
    private Toolbar toolbar;
    private DrawerLayout drawerLayout;
    private ImageView ivMenu;
    private TextView tvTitle;
    private TextView tvNavigationUsername;
    private TextView tvNavigationEmail;
    private CoordinatorLayout coordinatorLayout;
    private Handler handler;
    private TextView tvReconnected;

    ConversationsView(ConversationsController activity, ConversationsViewListener listener) {
        this.activity = activity;
        this.rootView = activity.findViewById(android.R.id.content);
        this.listener = listener;
        handler = new Handler(Looper.getMainLooper());
        initNav();
        initViews();
    }

    private void initNav() {
        drawerLayout = (DrawerLayout) rootView.findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(activity, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        ivMenu = (ImageView) rootView.findViewById(R.id.main_ala_action_bar_menu);
        tvTitle = (TextView) rootView.findViewById(R.id.main_ala_action_bar_title);
        NavigationView navigationView = (NavigationView) rootView.findViewById(R.id.nav_view);
        View hView = navigationView.getHeaderView(0);
        tvNavigationUsername = (TextView) hView.findViewById(R.id.nav_user_name);
        tvNavigationEmail = (TextView) hView.findViewById(R.id.nav_user_email);
        tvReconnected = (TextView) rootView.findViewById(R.id.main_connected_message);
        tvTitle.setText(activity.getText(R.string.app_name));
        ivMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
        navigationView.setNavigationItemSelectedListener(activity);
    }

    void setNavigationHeader() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                String username = ConnectionManager.getInstance().getUser().getUsername();
                if (username != null && username.length() > 2) {
                    tvNavigationUsername.setText(String.format(activity.getString(R.string.hey_user), username));
                    tvNavigationEmail.setText(ConnectionManager.getInstance().getUser().getEmail());
                }
            }
        });
    }

    private void initViews() {
        fabGoToAddHostController = (FloatingActionButton) rootView.findViewById(R.id.fab);
        coordinatorLayout = (CoordinatorLayout) rootView.findViewById(R.id.converstation_view_cl);
        fabGoToAddHostController.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onGoToAddHostController();
            }
        });
        toolbar = (Toolbar) rootView.findViewById(R.id.toolbar);
        activity.setSupportActionBar(toolbar);
        lvHostConnection = (ListView) rootView.findViewById(R.id.activity_main_connection_list);
        lvHostConnection.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int pos, long l) {
                listener.onConnectionSelected(pos);
            }
        });
    }

    void refreshList(final ConversationListAdapter adapter) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                adapter.notifyDataSetChanged();
            }
        });
    }


    public void showInfoReconnecting() {
        tvReconnected.setVisibility(View.VISIBLE);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                tvReconnected.setVisibility(View.GONE);
            }
        }, TimeHelper.SECONDS_THREE);
    }

    void setConnectionListAdapter(ConversationListAdapter conversationListAdapter) {
        lvHostConnection.setAdapter(conversationListAdapter);
    }

    interface ConversationsViewListener {
        void onGoToAddHostController();

        void onConnectionSelected(int pos);
    }
}
