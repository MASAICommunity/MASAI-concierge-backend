package com.mogree.travel_buddy.core.model.travelfolder_user;

import java.util.List;

/**
 * Created by cWahl on 23.08.2017.
 */

public class Hotel {

	private List<String> types;
	private List<String> categories;
	private List<String> locations;
	private List<String> bedTypes;
	private List<String> roomStandards;
	private List<String> roomLocations;
	private List<String> amenities;
	private List<String> chains;
	private List<String> chainsBlacklist;
	private List<HotelLoyaltyProgram> loyaltyPrograms;
	private String anythingElse;

	//region properties
	public List<String> getTypes() {
		return types;
	}

	public void setTypes(List<String> types) {
		this.types = types;
	}

	public List<String> getCategories() {
		return categories;
	}

	public void setCategories(List<String> categories) {
		this.categories = categories;
	}

	public List<String> getLocations() {
		return locations;
	}

	public void setLocations(List<String> locations) {
		this.locations = locations;
	}

	public List<String> getBedTypes() {
		return bedTypes;
	}

	public void setBedTypes(List<String> bedTypes) {
		this.bedTypes = bedTypes;
	}

	public List<String> getRoomStandards() {
		return roomStandards;
	}

	public void setRoomStandards(List<String> roomStandards) {
		this.roomStandards = roomStandards;
	}

	public List<String> getRoomLocation() {
		return roomLocations;
	}

	public void setRoomLocation(List<String> roomLocations) {
		this.roomLocations = roomLocations;
	}

	public List<String> getAmenities() {
		return amenities;
	}

	public void setAmenities(List<String> amenities) {
		this.amenities = amenities;
	}

	public List<String> getChains() {
		return chains;
	}

	public void setChains(List<String> chains) {
		this.chains = chains;
	}

	public List<String> getChainsBlacklist() {
		return chainsBlacklist;
	}

	public void setChainsBlacklist(List<String> chainsBlacklist) {
		this.chainsBlacklist = chainsBlacklist;
	}

	public List<HotelLoyaltyProgram> getLoyaltyPrograms() {
		return loyaltyPrograms;
	}

	public void setLoyaltyPrograms(List<HotelLoyaltyProgram> loyaltyPrograms) {
		this.loyaltyPrograms = loyaltyPrograms;
	}

	public String getAnythingElse() {
		return anythingElse;
	}

	public void setAnythingElse(String anythingElse) {
		this.anythingElse = anythingElse;
	}
	//endregion
}
