package com.mogree.travel_buddy.core.model.travelfolder_user;

import com.google.gson.annotations.SerializedName;

/**
 * Created by cWahl on 22.08.2017.
 */

public class ContactInfo {

	private String primaryEmail;
	private String primaryPhone;

	//region properties
	public String getPrimaryEmail() {
		return primaryEmail;
	}

	public void setPrimaryEmail(String primaryEmail) {
		this.primaryEmail = primaryEmail;
	}

	public String getPrimaryPhone() {
		return primaryPhone;
	}

	public void setPrimaryPhone(String primaryPhone) {
		this.primaryPhone = primaryPhone;
	}
	//endregion
}
