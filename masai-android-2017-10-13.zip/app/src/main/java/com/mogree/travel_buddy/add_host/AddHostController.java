package com.mogree.travel_buddy.add_host;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.chat.ChatController;
import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.helper.C;
import com.mogree.travel_buddy.core.model.Host;

import java.util.List;

public class AddHostController extends AppCompatActivity implements AddHostView.AddHostViewListener {
    private AddHostView view;
    private AddHostListAdapter addHostListAdapter;
    private Context context;
    private Handler handler;
    private List<Host> hostList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.context = this;
        handler = new Handler(Looper.getMainLooper());
        setContentView(R.layout.activity_server_list);
        view = new AddHostView(findViewById(android.R.id.content), this, this);
        view.setTitle(getString(R.string.select_host));
        hostList = ConnectionManager.getInstance().getHostList();
        if (hostList != null && hostList.size() > 0) {
            addHostListAdapter = new AddHostListAdapter(this, hostList);
            view.setAddHostListAdapter(addHostListAdapter);
        } else {
            finish();
        }
        if (ConnectionManager.getInstance().getHostConnectionList().size() == 0) {
            addConnection(0);
        }
    }

    private void addConnection(int position) {
        view.showProgress();
        ConnectionManager.getInstance().addConnection(context, position, true, new ConnectionManager.IConnectListener() {
            @Override
            public void onDisconnected(int pos) {
                view.showOkDialog(R.string.connection_restore);
                view.hideProgress();
            }

            @Override
            public void onConnectedAndLoggedIn(int pos) {
                startChat(pos);
                view.hideProgress();
            }

            @Override
            public void onBadPassword(int pos) {
                view.showOkDialog(R.string.incorrect_password);
                view.hideProgress();
            }

            @Override
            public void onUserNotFound(int pos) {
                view.showOkDialog(R.string.user_does_not_exist);
                view.hideProgress();
            }

            @Override
            public void onNoUsername(int pos) {
                view.showOkDialog(R.string.user_does_not_exist);
                view.hideProgress();
            }

            @Override
            public void onNewMessage(int pos) {

            }

            @Override
            public void onConnectivityError(int pos) {
                view.showOkDialog(R.string.connection_restore);
                view.hideProgress();
            }
        });
    }

    @Override
    public void onHostClicked(final int position) {
        int existsAtPos = ConnectionManager.getInstance().getHostPosition(position);
        if (existsAtPos > -1) {
            startChat(existsAtPos);
        } else {
            addConnection(position);
        }
    }

    @Override
    protected void onStop() {
        handler.removeCallbacksAndMessages(null);
        super.onStop();
    }

    private void startChat(int pos) {
        Intent intent = new Intent(context, ChatController.class);
        intent.putExtra(C.EXTRA_HOST_CONNECTION_POSITION, pos);
        finish();
        startActivity(intent);
    }

    @Override
    public void onNavigateBack() {
        onBackPressed();
    }
}
