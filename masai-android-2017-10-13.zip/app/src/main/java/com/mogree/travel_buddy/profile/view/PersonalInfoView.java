package com.mogree.travel_buddy.profile.view;

import android.content.Context;
import android.view.View;

import com.mogree.travel_buddy.core.model.travelfolder_user.PersonalData;
import com.mogree.travel_buddy.databinding.ActivityMydataPersonalInfoBinding;

/**
 * Created by cWahl on 22.08.2017.
 */

public class PersonalInfoView extends BaseView implements View.OnFocusChangeListener {

	private PersonalInfoView.PersonalInfoViewListener listener;
	private ActivityMydataPersonalInfoBinding binding;

	public PersonalInfoView(View rootView, Context context, PersonalInfoView.PersonalInfoViewListener listener,
	                        ActivityMydataPersonalInfoBinding binding) {
		super(rootView, context);
		this.listener = listener;
		this.binding = binding;
		setOnFocusChangedListener();
	}

	public void setOnFocusChangedListener() {
		binding.activityMydataPersonalInfoBirthdate.setOnFocusChangeListener(this);
		binding.activityMydataPersonalInfoTitle.setOnFocusChangeListener(this);
		binding.activityMydataPersonalInfoFirstname.setOnFocusChangeListener(this);
		binding.activityMydataPersonalInfoMiddlename.setOnFocusChangeListener(this);
		binding.activityMydataPersonalInfoLastname.setOnFocusChangeListener(this);
		binding.activityMydataPersonalInfoNationality.setOnFocusChangeListener(this);
	}

	public void setContent(PersonalData personalData) {
		if (personalData.getBirthdate() != null) {
			binding.activityMydataPersonalInfoBirthdate.setText(personalData.getBirthdate());
		}
		if (personalData.getFirstname() != null) {
			binding.activityMydataPersonalInfoFirstname.setText(personalData.getFirstname());
		}
		if (personalData.getLastname() != null) {
			binding.activityMydataPersonalInfoLastname.setText(personalData.getLastname());
		}
		if (personalData.getMiddlename() != null) {
			binding.activityMydataPersonalInfoMiddlename.setText(personalData.getMiddlename());
		}
		if (personalData.getNationality() != null) {
			binding.activityMydataPersonalInfoNationality.setText(personalData.getNationality());
		}
		if (personalData.getTitle() != null) {
			binding.activityMydataPersonalInfoTitle.setText(personalData.getTitle());
		}
	}

	@Override
	public void onFocusChange(View view, boolean isFocused) {
		super.onFocusChange(view, isFocused);

		if (!isFocused) {
			listener.updatePersonalData(view);
		}
	}

	public interface PersonalInfoViewListener {

		void updatePersonalData(View view);

		void onBackArrowPressed();
	}
}
