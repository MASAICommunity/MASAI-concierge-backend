package com.mogree.travel_buddy.core.helper;

import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.mogree.travel_buddy.core.model.travelfolder_user.Choice;
import com.mogree.travel_buddy.core.model.travelfolder_user.Choices;
import com.mogree.travel_buddy.core.model.travelfolder_user.ChoicesList;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import static com.mogree.travel_buddy.core.helper.DeserializerHelper.getListObject;
import static com.mogree.travel_buddy.core.helper.DeserializerHelper.getMapObject;
import static com.mogree.travel_buddy.core.helper.DeserializerHelper.getStringField;

/**
 * Created by cWahl on 25.08.2017.
 */

public class ChoicesConverter implements JsonDeserializer<ChoicesList> {

	@Override
	public ChoicesList deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
		final JsonArray jsonItems = json.getAsJsonObject().get("Items").getAsJsonArray();

		List<Choices> choicesTempList = new ArrayList<>();
		for (JsonElement jsonItem : jsonItems) {
			Choices choices = new Choices();
			choices.setDataKey(getStringField(jsonItem.getAsJsonObject(), "DataKey"));
			choices.setText(getStringField(jsonItem.getAsJsonObject(), "Text"));

			JsonArray jsonChoices = getListObject(jsonItem.getAsJsonObject(), "Choices");
			List<Choice> choiceTempList = new ArrayList<>();
			for (JsonElement jsonChoice : jsonChoices) {
				Choice choice = new Choice();
				choice.setValue(getStringField(getMapObject(jsonChoice.getAsJsonObject()), "Value"));
				choice.setText(getStringField(getMapObject(jsonChoice.getAsJsonObject()), "Text"));
				choiceTempList.add(choice);
			}
			choices.setChoices(choiceTempList);
			choicesTempList.add(choices);
		}

		ChoicesList choiceList = new ChoicesList();
		choiceList.setChoicesList(choicesTempList);

		return choiceList;
	}
}
