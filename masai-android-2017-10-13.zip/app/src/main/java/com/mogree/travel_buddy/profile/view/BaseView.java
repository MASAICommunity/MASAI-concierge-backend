package com.mogree.travel_buddy.profile.view;

import android.app.ProgressDialog;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.helper.ViewHelper;
import com.tolstykh.textviewrichdrawable.EditTextRichDrawable;

/**
 * Created by cWahl on 25.08.2017.
 */

public class BaseView implements View.OnFocusChangeListener{

	public View rootView;
	public Context context;
	public ProgressDialog progressDialog;

	public BaseView(View rootView, Context context) {
		this.rootView = rootView;
		this.context = context;
		initViews();
	}

	private void initViews() {
		progressDialog = new ProgressDialog(context, ProgressDialog.STYLE_SPINNER);
		progressDialog.setMessage(rootView.getContext().getString(R.string.loading_data));
		progressDialog.setCanceledOnTouchOutside(false);

		((AppCompatActivity) context).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		((AppCompatActivity) context).setTitle("Profil");
		((AppCompatActivity) context).getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
	}

	@Override
	public void onFocusChange(View view, boolean isFocused) {
		ViewHelper.EDIT_TEXT_STATE state;

		if (!isFocused) {
			if (((EditTextRichDrawable) view).getText().toString().length() > 0) {
				state = ViewHelper.EDIT_TEXT_STATE.OK;
			} else {
				state = ViewHelper.EDIT_TEXT_STATE.NOT_FOCUSED;
			}
		} else {
			state = ViewHelper.EDIT_TEXT_STATE.FOCUSED;
		}

		ViewHelper.setEditTextDrawableState(context, view, state);
	}
}
