package com.mogree.travel_buddy.profile.controller.my_data;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.mogree.travel_buddy.R;

/**
 * Created by cWahl on 25.08.2017.
 */

public class BillingAddressController extends AppCompatActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_mydata_billing_address);

		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
	}
}
