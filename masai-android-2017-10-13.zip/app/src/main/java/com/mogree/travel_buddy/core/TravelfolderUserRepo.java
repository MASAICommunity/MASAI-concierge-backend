package com.mogree.travel_buddy.core;

import com.mogree.travel_buddy.core.model.travelfolder_user.ChoicesList;
import com.mogree.travel_buddy.core.model.travelfolder_user.PersonalData;
import com.mogree.travel_buddy.core.model.travelfolder_user.TravelfolderUser;

/**
 * Created by cWahl on 24.08.2017.
 */

public class TravelfolderUserRepo {

	private static TravelfolderUserRepo instance;
	private TravelfolderUser travelfolderUser;
	private ChoicesList choiceList;

	private TravelfolderUserRepo() {
	}

	public static TravelfolderUserRepo getInstance() {
		if (instance == null) {
			instance = new TravelfolderUserRepo();
		}
		return instance;
	}

	//region properties
	public TravelfolderUser getTravelfolderUser() {
		return travelfolderUser;
	}

	public void setTravelfolderUser(TravelfolderUser travelfolderUser) {
		this.travelfolderUser = travelfolderUser;
	}

	public ChoicesList getChoiceList() {
		return choiceList;
	}

	public void setChoiceList(ChoicesList choiceList) {
		this.choiceList = choiceList;
	}
	//endregion
}
