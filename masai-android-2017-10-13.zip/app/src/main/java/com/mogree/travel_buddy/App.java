package com.mogree.travel_buddy;

import android.content.Context;
import android.support.multidex.MultiDexApplication;
import android.widget.Toast;

import com.google.gson.GsonBuilder;
import com.mogree.travel_buddy.core.BackendManager;
import com.mogree.travel_buddy.core.Foreground;
import com.mogree.travel_buddy.core.TravelfolderUserRepo;
import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.helper.ChoicesConverter;
import com.mogree.travel_buddy.core.helper.TravelfolderUserConverter;
import com.mogree.travel_buddy.core.model.User;
import com.mogree.travel_buddy.core.model.travelfolder_user.ChoicesList;
import com.mogree.travel_buddy.core.model.travelfolder_user.TravelfolderUser;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.mogree.travel_buddy.core.BackendManager.AUTHORIZATION_BEARER_PREFIX;

/**
 * Created by Semko on 2017-01-12.
 */

public class App extends MultiDexApplication implements Foreground.Listener {

	private static Context context;

	public void onCreate() {
		super.onCreate();
		context = this;
		Foreground.init(this).addListener(this);
	}

	@Override
	public void onBecameForeground() {
		initTravelFolderUser();
		initChoices();
	}

	@Override
	public void onBecameBackground() {
		//ToDo update Travelfolderuser via webservice
	}

	private void initTravelFolderUser() {
		if (TravelfolderUserRepo.getInstance().getTravelfolderUser() == null) {
			final User user = ConnectionManager.getInstance().getUser();
			BackendManager.getInstance().getBackendService().getTravelfolderUser(AUTHORIZATION_BEARER_PREFIX + user.getIdToken())
					.enqueue(new Callback<okhttp3.ResponseBody>() {
						@Override
						public void onResponse(Call<okhttp3.ResponseBody> call, Response<okhttp3.ResponseBody> response) {
							if(response.errorBody() == null) {
								GsonBuilder gsonBuilder = new GsonBuilder();
								gsonBuilder.registerTypeAdapter(TravelfolderUser.class, new TravelfolderUserConverter());
								TravelfolderUser travelUser = null;
								try {
									travelUser = gsonBuilder.create().fromJson(response.body().string(), TravelfolderUser.class);
								} catch (IOException e) {
									e.printStackTrace();
									showError();
								}
								TravelfolderUserRepo.getInstance().setTravelfolderUser(travelUser);
							}
							else showError();
						}

						@Override
						public void onFailure(Call<okhttp3.ResponseBody> call, Throwable t) {
							showError();
						}
					});
		}
	}

	private void initChoices() {
		if (TravelfolderUserRepo.getInstance().getChoiceList() == null) {
			BackendManager.getInstance().getBackendService().getChoices()
					.enqueue(new Callback<okhttp3.ResponseBody>() {
						@Override
						public void onResponse(Call<okhttp3.ResponseBody> call, Response<okhttp3.ResponseBody> response) {
							if(response.errorBody() == null) {
								GsonBuilder gsonBuilder = new GsonBuilder();
								gsonBuilder.registerTypeAdapter(ChoicesList.class, new ChoicesConverter());
								ChoicesList choicesList = null;
								try {
									choicesList = gsonBuilder.create().fromJson(response.body().string(), ChoicesList.class);
								} catch (IOException e) {
									e.printStackTrace();
									showError();
								}
								TravelfolderUserRepo.getInstance().setChoiceList(choicesList);
							}
							else showError();
						}

						@Override
						public void onFailure(Call<okhttp3.ResponseBody> call, Throwable t) {
							showError();
						}
					});
		}
	}

	public static Context getContext() {
		return context;
	}

	private void showError() {
		Toast.makeText(this.getApplicationContext(), "Travelfolder Benutzer konnte nicht geladen werden!", Toast.LENGTH_LONG).show();
	}
}
