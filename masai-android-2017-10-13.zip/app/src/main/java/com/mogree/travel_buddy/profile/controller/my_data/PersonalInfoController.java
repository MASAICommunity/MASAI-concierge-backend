package com.mogree.travel_buddy.profile.controller.my_data;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.view.View;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.TravelfolderUserRepo;
import com.mogree.travel_buddy.core.model.travelfolder_user.PersonalData;
import com.mogree.travel_buddy.databinding.ActivityMydataPersonalInfoBinding;
import com.mogree.travel_buddy.profile.controller.BaseController;
import com.mogree.travel_buddy.profile.view.PersonalInfoView;
import com.tolstykh.textviewrichdrawable.EditTextRichDrawable;

public class PersonalInfoController extends BaseController implements PersonalInfoView.PersonalInfoViewListener {

	private PersonalInfoView personalInfoView;
	private ActivityMydataPersonalInfoBinding binding;
	private PersonalData personalData;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		binding = DataBindingUtil.setContentView(this, R.layout.activity_mydata_personal_info);
		personalInfoView = new PersonalInfoView(binding.getRoot(), this, this, binding);

		personalData = TravelfolderUserRepo.getInstance().getTravelfolderUser().getPersonalData();
		if (personalData == null) {
			personalData = new PersonalData();
		}
		personalInfoView.setContent(personalData);
	}

	@Override
	public void updatePersonalData(View view) {
		switch (view.getId()) {
		case R.id.activity_mydata_personal_info_birthdate:
			personalData.setBirthdate(((EditTextRichDrawable) view).getText().toString());
			break;
		case R.id.activity_mydata_personal_info_title:
			personalData.setTitle(((EditTextRichDrawable) view).getText().toString());
			break;
		case R.id.activity_mydata_personal_info_firstname:
			personalData.setFirstname(((EditTextRichDrawable) view).getText().toString());
			break;
		case R.id.activity_mydata_personal_info_middlename:
			personalData.setMiddlename(((EditTextRichDrawable) view).getText().toString());
			break;
		case R.id.activity_mydata_personal_info_lastname:
			personalData.setLastname(((EditTextRichDrawable) view).getText().toString());
			break;
		case R.id.activity_mydata_personal_info_nationality:
			personalData.setNationality(((EditTextRichDrawable) view).getText().toString());
			break;
		default:
			break;
		}

		TravelfolderUserRepo.getInstance().getTravelfolderUser().setPersonalData(personalData);
		personalInfoView.setContent(personalData);
	}
}
