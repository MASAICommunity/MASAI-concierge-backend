//
//  ProfileTransformatorTests.swift
//  masai
//
//  Created by Florian Rath on 18.08.17.
//  Copyright © 2017 Codepool GmbH. All rights reserved.
//

import XCTest
import SwiftyJSON


class ProfileTransformatorTests: XCTestCase {
    
    
    
    override func setUp() {
        super.setUp()
    }
    
    override func tearDown() {
        super.tearDown()
    }
    
    func testExample() {
        let u = User()
        u.identifier = "3b6d416625d50e7a"
        
        let profileString = ""
        
        let response = ProfileTransformator.transform(profileString: profileString, user: u)
        XCTAssertEqual(response, expectedPostPayload)
    }
    
}


extension ProfileTransformatorTests {
    
    var expectedPostPayload: String {
        return "{\"IdentitySource\":{\"S\":\"auth0\"},\"UserId\":{\"S\":\"3b6d416625d50e7a\"},\"personal\":{\"M\":{\"title\":{\"S\":\"new title\"},\"first_name\":{\"S\":\"new first\"},\"middle_name\":{\"S\":\"new middle\"},\"last_name\":{\"S\":\"new last\"},\"nationality\":{\"S\":\"My nation\"},\"birth_date\":{\"S\":\"01.01.1111\"}}},\"contact\":{\"M\":{\"passport\":{\"M\":{\"number\":{\"S\":\"pass numb\"},\"country\":{\"S\":\"country of issuance\"},\"city\":{\"S\":\"city\"},\"date_issued\":{\"S\":\"01.01.111\"},\"expiry\":{\"S\":\"01.01.111\"}}},\"primary_email\":{\"S\":\"email@mail.mail\"},\"primary_phone\":{\"S\":\"12341234\"},\"address_billing\":{\"M\":{\"company_name\":{\"S\":\"company 1\"},\"address_line_1\":{\"S\":\"address line 1 2\"},\"address_line_2\":{\"S\":\"address line 2 2\"},\"city\":{\"S\":\"city 2\"},\"state\":{\"S\":\"state 2\"},\"zip\":{\"S\":\"zip 2\"},\"country\":{\"S\":\"country 2\"},\"vat\":{\"S\":\"vat vat vat\"}}},\"esta\":{\"M\":{\"application_number\":{\"S\":\"application number\"},\"valid_until\":{\"S\":\"01.01.1111\"}}}}},\"preference\":{\"M\":{\"flights\":{\"M\":{\"booking_class_short_haul\":{\"S\":\"economy\"},\"booking_class_medium_haul\":{\"S\":\"premium_economy\"},\"booking_class_long_haul\":{\"S\":\"premium_economy\"},\"seat\":{\"S\":\"middle\"},\"seat_row\":{\"S\":\"middle\"},\"meal\":{\"S\":\"gfml_glutenfree\"},\"options\":{\"L\":[{\"S\":\"no_bulkhead\"},{\"S\":\"not_close_to_bathroom\"},{\"S\":\"extra_leg_room\"}]},\"airlines\":{\"L\":[{\"S\":\"air_asia\"},{\"S\":\"all_nippon_airways\"}]},\"airlines_blacklist\":{\"L\":[{\"S\":\"air_asia\"}]},\"airline_loyalty_program\":{\"L\":[{\"M\":{\"id\":{\"S\":\"airport_club\"},\"number\":{\"S\":\"1234\"}}}]},\"anything_else\":{\"S\":\"nothing\"}}},\"hotel\":{\"M\":{\"types\":{\"L\":[{\"S\":\"boutique\"}]},\"categories\":{\"L\":[{\"S\":\"superior\"},{\"S\":\"luxury\"},{\"S\":\"first_class\"},{\"S\":\"comfort\"},{\"S\":\"standard\"}]},\"location\":{\"L\":[{\"S\":\"quiet\"}]},\"bed_types\":{\"L\":[{\"S\":\"king\"}]},\"room_standards\":{\"L\":[{\"S\":\"air_condition\"},{\"S\":\"allergic\"},{\"S\":\"non_smoking\"}]},\"room_location\":{\"L\":[{\"S\":\"high_up\"},{\"S\":\"far_from_elevator\"},{\"S\":\"quiet\"}]},\"amenities\":{\"L\":[{\"S\":\"pool\"},{\"S\":\"spa\"},{\"S\":\"fitness\"},{\"S\":\"parking\"},{\"S\":\"breakfast\"},{\"S\":\"wifi\"}]},\"chains\":{\"L\":[{\"S\":\"design_hotels\"},{\"S\":\"grand_city\"},{\"S\":\"intercontinental\"},{\"S\":\"hilton\"},{\"S\":\"ibis\"}]},\"chains_blacklist\":{\"L\":[{\"S\":\"best_western\"}]},\"loyalty_program\":{\"L\":[{\"M\":{\"id\":{\"S\":\"club_carlson\"},\"number\":{\"S\":\"1234\"}}},{\"M\":{\"id\":{\"S\":\"gold_points_plus\"},\"number\":{\"S\":\"1234\"}}},{\"M\":{\"id\":{\"S\":\"gold_points_plus\"},\"number\":{\"S\":\"1234\"}}}]},\"anything_else\":{\"S\":\"allergic to pee stains\"}}},\"car\":{\"M\":{\"booking_class\":{\"S\":\"intermediate\"},\"type\":{\"S\":\"van\"},\"preferences\":{\"L\":[{\"S\":\"automatic\"},{\"S\":\"electric\"},{\"S\":\"gps\"},{\"S\":\"4wheel\"},{\"S\":\"air_condition\"}]},\"extras\":{\"L\":[{\"S\":\"kilometers\"},{\"S\":\"insurance\"}]},\"rental_companies\":{\"L\":[{\"S\":\"enterprise\"}]},\"loyalty_programs\":{\"L\":[{\"M\":{\"id\":{\"S\":\"enterprise_plus\"},\"number\":{\"S\":\"1234\"}}}]},\"anything_else\":{\"S\":\"1234\"}}},\"train\":{\"M\":{\"anything_else\":{\"S\":\"qwer\"},\"loyalty_programs\":{\"L\":[{\"M\":{\"id\":{\"S\":\"db_bahncard_25_first\"},\"number\":{\"S\":\"1234\"}}},{\"M\":{\"id\":{\"S\":\"db_bahncard_25_first\"},\"number\":{\"S\":\"1234\"}}}]}}}}},\"address_private\":{\"M\":{\"address_line_1\":{\"S\":\"Address line 1 1\"},\"address_line_2\":{\"S\":\"Address line 2 1\"},\"city\":{\"S\":\"City 1\"},\"state\":{\"S\":\"state 1\"},\"zip\":{\"S\":\"zip 1\"},\"country\":{\"S\":\"Country 1\"}}},\"created\":{\"N\":\"1503050395912\"},\"modified\":{\"N\":\"1503050395912\"}}"
    }
    
}
