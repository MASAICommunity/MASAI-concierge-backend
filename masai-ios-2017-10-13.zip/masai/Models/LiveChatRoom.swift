//
//  LiveChatRoom.swift
//  masai
//
//  Created by Bartomiej Burzec on 21.04.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import Foundation
import RealmSwift
import Realm

public class LiveChatRoom: BaseDatabaseModel {
    
    dynamic var auth0UserIdentifier: String?
    
    dynamic var hostUrl: String?
    dynamic var hostSocket: String?
    dynamic var hostname: String?
    
    dynamic var channelName: String?
    dynamic var channelIdentifier: String?
    dynamic var channelRid: String?
    
    dynamic var liveChatToken: String?
    dynamic var liveChatUserId: String?
    dynamic var liveChatUsername: String?
    
    
    func update(_ conversation: Conversation) {
        self.hostUrl = conversation.host?.url
        self.hostSocket = conversation.host?.socket
        self.hostname = conversation.host?.name
        
        self.channelName = conversation.channel?.name
        self.channelIdentifier =  conversation.channel?.identifier
        self.channelRid = conversation.channel?.rid
        
        self.liveChatToken = conversation.credentials?.liveChatToken
        self.liveChatUserId = conversation.credentials?.liveChatUserId
        self.liveChatUsername = conversation.credentials?.liveChatUsername
        
        if self.identifier == nil {
            self.identifier = UUID().uuidString
        }
    }
    
    func conversation() -> Conversation {
        return Conversation(self)
    }
    
}
