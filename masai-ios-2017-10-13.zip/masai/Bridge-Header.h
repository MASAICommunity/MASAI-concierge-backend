//
//  Bridge-Header.h
//  masai
//
//  Created by Bartomiej Burzec on 27.01.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

#ifndef Bridge_Header_h
#define Bridge_Header_h

#import "CommonCrypto/CommonCrypto.h"

#endif /* Bridge_Header_h */
