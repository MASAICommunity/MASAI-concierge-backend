//
//  SocketManager+ResponseHandler.swift
//  masai
//
//  Created by Bartomiej Burzec on 25.01.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//
import SwiftyJSON
import Starscream
import RealmSwift

extension SocketManager {
    
    func handleResponse(_ response: JSON, socket: WebSocket) {
        let responseMessage = SocketResponseMessage(response)
        
        guard let message = responseMessage.messageType else {
            print("Response Message type is invalid \(responseMessage.responseData)")
            return
        }
        
        switch message {
        case .Ping:  return handlePongMessage(responseMessage, socket: socket)
        case .Changed, .Added, .Removed: return handleSubcription(responseMessage, socket: socket)
        default: break
        }
        
        guard let responseIdentifier = responseMessage.identifier else {
            return
        }
        
        if let completionsForSocket = self.responseQueue[socket.key()] {
            let completion = completionsForSocket[responseIdentifier]
            completion?(responseMessage)
        }
    }
    
    func handlePongMessage(_ message: SocketResponseMessage, socket: WebSocket) {
        SocketManager.send([Constants.Network.Json.message: Constants.Network.Json.pong], url: socket.currentURL)
    }
    
    func handleSubcription(_ message: SocketResponseMessage, socket: WebSocket) {
        if let event =  message.event, let delegates = self.subscribedConversationDelegates[event] {
            let chatMessageJson = message.responseData[Constants.Network.Json.fields][Constants.Network.Json.args][0]
            
            if let newMessage = MessageParser.parse(chatMessageJson) {
                for delegate in delegates {
                    DispatchQueue.main.async {
                        delegate.onUpdate(message: newMessage, response: message)
                    }
                }
            }
        }
    }
    
}
