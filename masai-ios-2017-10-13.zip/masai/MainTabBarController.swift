//
//  MainTabBarController.swift
//  masai
//
//  Created by Florian Rath on 19.08.17.
//  Copyright © 2017 Codepool GmbH. All rights reserved.
//

import Foundation
import UIKit


class MainTabBarController: UITabBarController {
    
    // MARK: Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setup()
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        setup()
        updateTitles()
    }
    
    
    // MARK: Setup
    
    private func setup() {
        if let navController = navigationController as? BaseNavigationController {
            navController.hideStatusBarBackgroundView = true
        }
        
        self.delegate = self
    }
    
    
    // MARK: Private
    
    private func updateTitles() {
        for vc in (viewControllers ?? []) {
            vc.view.layoutIfNeeded()
        }
    }
    
}


// MARK: UITabBarControllerDelegate
extension MainTabBarController: UITabBarControllerDelegate {
    
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        if let fromNavC = tabBarController.selectedViewController as? BaseNavigationController,
            let toNavC = viewController as? BaseNavigationController,
            let fromVC = fromNavC.childViewControllers.first as? ProfileViewController,
            let toVC = toNavC.childViewControllers.first,
            fromVC != toVC {
            let userProfile = CacheManager.retrieveUserProfile()
            userProfile?.postToBackendIfNeeded()
        }
        
        return true
    }
    
}
