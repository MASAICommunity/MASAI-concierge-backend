//
//  LiveChatManager.swift
//  masai
//
//  Created by Bartomiej Burzec on 21.04.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import Foundation
import Realm
import RealmSwift

typealias ConversationForUserCompletion  = ([Conversation]) -> Void

struct LiveChatManager {
    
    static func conversationsForUser(results: ConversationForUserCompletion) {
        guard let user = CacheManager.retrieveLoggedUser(), let userId = user.identifier, let rooms = try? Realm().objects(LiveChatRoom.self).filter("auth0UserIdentifier == %@", userId)  else {
            
            results([])
            return
        }
        
        results(rooms.flatMap({
        $0.conversation()
        }))
        
        return
    }
    
    static func removeRoom(with conversation: Conversation) {
        guard let user = CacheManager.retrieveLoggedUser(), let userId = user.identifier, let roomId = conversation.channel?.rid, let rooms = try? Realm().objects(LiveChatRoom.self).filter("auth0UserIdentifier == %@ AND channelRid == %@", userId, roomId)  else {
            return
        }

        Realm.execute { (realm) in
            realm.delete(rooms)
        }
    }
    
    static func add(_ conversation: Conversation) -> Bool {
        if let user = CacheManager.retrieveLoggedUser(), let userId = user.identifier {
            
            let newRoom = LiveChatRoom()
            newRoom.update(conversation)
            newRoom.auth0UserIdentifier = userId

            Realm.execute({ (realm) in
                realm.add(newRoom)
            })
            return true
        }
        return false
    }
    
}
