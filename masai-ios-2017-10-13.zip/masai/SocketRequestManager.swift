//
//  SockeRequestManager.swift
//  masai
//
//  Created by Bartomiej Burzec on 03.02.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import Foundation
import RealmSwift
import SwiftyJSON

typealias SubscriptionResponseCompletion = (SocketResponseMessage, [Channel]?) -> Void
typealias CreateChannelResponseCompletion = (SocketResponseMessage, Channel?) -> Void
typealias LoadHistoryResponseCompletion = (SocketResponseMessage, [ChatMessage]?) -> Void
typealias SendTextMessageResponseCompletion = (SocketResponseMessage) -> Void
typealias ResetPassResponsecCompletion = (SocketResponseMessage, Bool?) -> Void
typealias RegisterToLiveChatCompletion = (SocketResponseMessage?, Channel?, LiveChatCredentials?) -> Void
typealias LoginLiveChatResponseCompletion = (SocketResponseMessage?) -> Void
typealias SendLocalizationResponseCompletion = (SocketResponseMessage) -> Void

struct SocketRequestManager {
    
    
    static func resendLocalization(_ conversation: Conversation, message: ChatMessage) {
        if let rid = conversation.channel?.rid, let host = conversation.host, let msgIdentifier = message.identifier {
            
            let requestObject = [
                Constants.Network.Json.message: Constants.Network.Json.method,
                Constants.Network.Json.method: Constants.Network.Methods.sendMessage,
                Constants.Network.Json.params: [[
                    Constants.Network.Json.location: [
                        Constants.Network.Json.coordinates: [message.longitude, message.latitude],
                        Constants.Network.Json.type: Constants.Network.Json.point
                    ],
                    Constants.Network.Json.identifier: msgIdentifier,
                    Constants.Network.Json.rid: rid,
                    Constants.Network.Json.timestamp: [
                        Constants.Network.Json.date: Date.masaiTimestampFromDate(Date())],
                    Constants.Network.Json.message: ""
                    ]]
                ] as [String : Any]
            
            
            SocketManager.send(requestObject, host: host) { _ in
            }
        }
    }
    
    static func sendLocalization(_ conversation: Conversation, lat: Double, long: Double, name: String?, completion: SendLocalizationResponseCompletion?) -> ChatMessage? {
        if let rid = conversation.channel?.rid, let host = conversation.host {
            
            let messageIdentifier = String.random(length: 18)
            
            let requestObject = [
                Constants.Network.Json.message: Constants.Network.Json.method,
                Constants.Network.Json.method: Constants.Network.Methods.sendMessage,
                Constants.Network.Json.params: [[
                    Constants.Network.Json.location: [
                        Constants.Network.Json.coordinates: [long, lat],
                        Constants.Network.Json.type: Constants.Network.Json.point
                    ],
                    Constants.Network.Json.identifier: messageIdentifier,
                    Constants.Network.Json.rid: rid,
                    Constants.Network.Json.timestamp: [
                        Constants.Network.Json.date: Date.masaiTimestampFromDate(Date())],
                    Constants.Network.Json.message: ""
                    ]]
                ] as [String : Any]
            
            var messageOwner = ""
            if let username = CacheManager.retrieveLoggedUser()?.username {
                messageOwner = username
            }
            
            let messageObject = [
                Constants.Network.Json.identifier: messageIdentifier,
                Constants.Network.Json.rid: rid,
                Constants.Network.Json.message: "",
                Constants.Network.Json.timestamp: [
                    Constants.Network.Json.date: Date.masaiTimestampFromDate(Date())],
                Constants.Network.Json.location: [
                    Constants.Network.Json.coordinates: [long, lat],
                    Constants.Network.Json.type: Constants.Network.Json.point
                ],
                Constants.Network.Json.userInfo:[
                    Constants.Network.Json.username: messageOwner
                ]] as [String: Any]
            
            let messageJson = JSON(messageObject)
            let newMessage = ChatMessage.getOrCreate(identifier: messageJson[Constants.Network.Json.identifier].string, jsonData: messageJson, updates: nil)
            
            Realm.execute({ (realm) in
                newMessage.locationName = name
                newMessage.sending = SocketManager.sharedInstance.isConnected(with: conversation)
                newMessage.locationAttached = true
                realm.add(newMessage, update: true)
            })
            
            SocketManager.send(requestObject, host: host) { (response) in
                completion?(response)
            }
            
            return newMessage
        }
        return nil
    }
    
    static func resendTextMessage(_ conversation: Conversation, message: ChatMessage) {
        if let rid = conversation.channel?.rid, let host = conversation.host, let msgIdentifier = message.identifier, let msg = message.messageText {
            
            let requestObject = [
                Constants.Network.Json.message: Constants.Network.Json.method,
                Constants.Network.Json.method: Constants.Network.Methods.sendMessage,
                Constants.Network.Json.params: [[
                    Constants.Network.Json.identifier: msgIdentifier,
                    Constants.Network.Json.rid: rid,
                    Constants.Network.Json.message: msg,
                    Constants.Network.Json.timestamp: [
                        Constants.Network.Json.date: Date.masaiTimestampFromDate(Date())],
                    
                    ]]
                ] as [String : Any]
            
            SocketManager.send(requestObject, host: host) { _ in
            }
        }
    }
    
    
    static func sendTextMessage(_ conversation: Conversation, message: String, completion: SendTextMessageResponseCompletion?) -> ChatMessage? {
        
        if let rid = conversation.channel?.rid, let host = conversation.host {
            
            let messageIdentifier = String.random(length: 18)
            
            let requestObject = [
                Constants.Network.Json.message: Constants.Network.Json.method,
                Constants.Network.Json.method: Constants.Network.Methods.sendMessage,
                Constants.Network.Json.params: [[
                    Constants.Network.Json.identifier: messageIdentifier,
                    Constants.Network.Json.rid: rid,
                    Constants.Network.Json.message: message,
                    Constants.Network.Json.timestamp: [
                        Constants.Network.Json.date: Date.masaiTimestampFromDate(Date())],

                    ]]
                ] as [String : Any]
            
            var messageOwner = ""
            if let username = conversation.credentials?.liveChatUsername {
                messageOwner = username
            }
            
            let messageObject = [
                Constants.Network.Json.identifier: messageIdentifier,
                Constants.Network.Json.rid: rid,
                Constants.Network.Json.message: message,
                Constants.Network.Json.timestamp: [
                    Constants.Network.Json.date: Date.masaiTimestampFromDate(Date())],
                Constants.Network.Json.userInfo:[
                    Constants.Network.Json.username: messageOwner
                ]] as [String: Any]
            
            let messageJson = JSON(messageObject)
            let newMessage = ChatMessage.getOrCreate(identifier: messageJson[Constants.Network.Json.identifier].string, jsonData: messageJson, updates: nil)
            
            Realm.execute({ (realm) in
                newMessage.sending = SocketManager.sharedInstance.isConnected(with: conversation)
                realm.add(newMessage, update: true)
            })
            
            SocketManager.send(requestObject, host: host) { (response) in
                completion?(response)
            }
            
            return newMessage
        }
        return nil
    }
    
    
    static func registerToLiveChat(host: Host, completion:@escaping RegisterToLiveChatCompletion) {
        
        guard let user = CacheManager.retrieveLoggedUser(), let token = user.auth0AccessToken  else {
            completion(nil, nil, nil)
            return
        }

        let requestObject: [String: Any] = [
            Constants.Network.Json.message: Constants.Network.Json.method,
            Constants.Network.Json.method: Constants.Network.Methods.getInitialData,
            Constants.Network.Json.params: [token]
        ]
        
        SocketManager.send(requestObject, host: host) { (response) in
           
            guard response.errorOccured() == false else {
                completion(response, nil, nil)
                return
            }
            self.registerLiveChatUser(host: host, token: token, completion: completion)
        }
        
    }
    
    static func registerLiveChatUser(host: Host,token: String, completion: @escaping RegisterToLiveChatCompletion) {
        
        if let user = CacheManager.retrieveLoggedUser(), let userId = user.identifier, let username = user.username {
            
            var email = ""
            if let userEmail = user.email {
                email = userEmail
            }
            
            let requestObject: [String: Any] = [
                Constants.Network.Json.message: Constants.Network.Json.method,
                Constants.Network.Json.method: Constants.Network.Methods.registerGuest,
                Constants.Network.Json.params: [[
                    Constants.Network.Json.token: token,
                    Constants.Network.Json.name: username,
                    Constants.Network.Json.email: email
                    ]]
            ]
            
            SocketManager.send(requestObject, host: host, completionResponse: { (response) in
                guard response.errorOccured() == false else {
                    completion(response, nil, nil)
                    return
                }
                
                if let liveChatUserId = response.responseData[Constants.Network.Json.result][Constants.Network.Json.userId].string, let userLoginToken = response.responseData[Constants.Network.Json.result][Constants.Network.Json.token].string {
                    
                    loginToLiveChat(host: host, token: userLoginToken, completion: { (response) in
                        if response?.errorOccured() == true {
                            completion(response, nil, nil)
                        } else {
                            sendLiveChatMessage(host: host, userLiveChatId: liveChatUserId, userLoginToken: userLoginToken, token: token, username: username, completion: completion)
                        }
                    })
                    
                } else {
                    completion(response, nil, nil)
                }
            })
        } else {
            completion(nil, nil, nil)
        }
    }
    
    
    static func loginToLiveChat(host: Host, token: String, completion: @escaping LoginLiveChatResponseCompletion) {
        
            let requestObject: [String: Any] = [
                Constants.Network.Json.message: Constants.Network.Json.method,
                Constants.Network.Json.method: Constants.Network.Methods.login,
                Constants.Network.Json.params: [[
                    Constants.Network.Json.resume: token
                    ]]
            ]
            
            SocketManager.send(requestObject, host: host, completionResponse: { (response) in
                completion(response)
            })
    }
    
    static func sendLiveChatMessage(host: Host, userLiveChatId: String, userLoginToken: String, token: String, username: String, completion: @escaping RegisterToLiveChatCompletion) {
        
            let randomRid = String.random(length: 17)
            
            let requestObject: [String: Any] = [
                Constants.Network.Json.message: Constants.Network.Json.method,
                Constants.Network.Json.method: Constants.Network.Methods.sendLiveChatMessage,
                Constants.Network.Json.params: [[
                    Constants.Network.Json.identifier: String.random(length: 17),
                    Constants.Network.Json.token: token,
                    Constants.Network.Json.message: "live_chat_welcome_message".localized,
                    Constants.Network.Json.rid: randomRid
                    ]]
            ]
  
            SocketManager.send(requestObject, host: host, completionResponse: { (response) in
                guard response.errorOccured() == false else {
                    completion(response, nil, nil)
                    return
                }
    
                var newChannel = Channel()
                newChannel.update(with: response.responseData[Constants.Network.Json.result])
                newChannel.name = host.name
                
                
                var newCredentials = LiveChatCredentials()
                newCredentials.liveChatToken = userLoginToken
                newCredentials.liveChatUsername = response.responseData[Constants.Network.Json.result][Constants.Network.Json.userInfo][Constants.Network.Json.username].string
                newCredentials.liveChatUserId = response.responseData[Constants.Network.Json.result][Constants.Network.Json.userInfo][Constants.Network.Json.identifier].string
                
                completion(response, newChannel, newCredentials)
        
            })
    }

    static func loadHistory(_ conversation: Conversation) {
        if let rid = conversation.channel?.rid, let host = conversation.host, let lastMessageDate = conversation.lastMessage()?.date {
            let requestObject = [
                Constants.Network.Json.message: Constants.Network.Json.method,
                Constants.Network.Json.method: Constants.Network.Methods.loadHistory,
                Constants.Network.Json.params: [
                    rid,[Constants.Network.Json.date : Date.masaiTimestampFromDate(Date())] , 50, [Constants.Network.Json.date : Date.masaiTimestampFromDate(lastMessageDate)]]
                ] as [String: Any]
            
            SocketManager.send(requestObject, host: host) { (response) in
                guard response.errorOccured() == false else {
                    return
                }
                
                for jsonMessage in response.responseData[Constants.Network.Json.result][Constants.Network.Json.messages].arrayValue {
                   let _ = MessageParser.parse(jsonMessage)
                }
                
                DispatchQueue.main.async {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: Constants.Notification.historyLoaded), object: nil)
                }
            }
        }
    }
    
    static func subscriptions(_ host: Host, completion: SubscriptionResponseCompletion? = nil) {
        let requestObject = [
            Constants.Network.Json.message: Constants.Network.Json.method,
            Constants.Network.Json.method: Constants.Network.Methods.subscriptions,
            Constants.Network.Json.params: [
                [Constants.Network.Json.date: 0]
                ]
            ] as [String: Any]
        
        SocketManager.send(requestObject, host: host) { (response) in
            
            if response.errorOccured() {
                completion?(response, nil)
                return
            }
            
            var chanels = [Channel]()
            if let channelArray = response.responseData[Constants.Network.Json.result][Constants.Network.Json.update].array {
                for channelJson in channelArray {
                    let channel = Channel(channelJson)
                    chanels.append(channel)
                }
                /* FIX for other json structure in response on different host */
            } else if let channelArray = response.responseData[Constants.Network.Json.result].array {
                for channelJson in channelArray {
                    let channel = Channel(channelJson)
                    chanels.append(channel)
                }
            }
            /* ---  */
            completion?(response, chanels)
        }
    }
    
    static func createChannel(_ name: String, host: Host, completion: CreateChannelResponseCompletion? = nil) {
        let requestObject = [
            Constants.Network.Json.message: Constants.Network.Json.method,
            Constants.Network.Json.method: Constants.Network.Methods.createChannel,
            Constants.Network.Json.params: [
                name,[], false
            ]
            ] as [String: Any]
        SocketManager.send(requestObject, host: host) { (response) in
            guard response.errorOccured() == false else {
                completion?(response, nil)
                return
            }
            
            var createdChannel = Channel(response.responseData[Constants.Network.Json.result])
            createdChannel.name = name
            completion?(response, createdChannel)
        }
    }
    
    static func resetPass(for email: String, host: Host, completion:ResetPassResponsecCompletion?) {
        let requestObject = [
            Constants.Network.Json.message: Constants.Network.Json.method,
            Constants.Network.Json.method: Constants.Network.Methods.resetPass,
            Constants.Network.Json.params: [
            email
        ]] as [String: Any]
        
        SocketManager.send(requestObject, host: host) { (response) in
            guard response.errorOccured() == false else {
                completion?(response, false)
                return
            }
            
            let result = response.responseData[Constants.Network.Json.result].bool
            completion?(response, result)
        }
    }
    
}
