//
//  SplashViewController.swift
//  masai
//
//  Created by Bartomiej Burzec on 19.01.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import UIKit

class SplashViewController: MasaiBaseViewController {
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var masaiLogo: UIImageView!
    @IBOutlet weak var loadingLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareLayout()
        
        if let navController = navigationController as? BaseNavigationController {
            navController.hideStatusBarBackgroundView = true
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        loadingLabel.text = "splashscreen_loading_text".localized
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        connectToChat()
        self.activityIndicator.isHidden = false
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func isNavigationBarVisible() -> Bool {
        return false
    }
    
    private func prepareLayout() {
        self.masaiLogo.image = self.masaiLogo.image!.withRenderingMode(.alwaysTemplate)
        self.masaiLogo.tintColor = .orangeMasai
    }
    
    private func connectToChat() {
        SocketManager.connect(Host.main()) { (socket, connected) in
            if connected {
                self.autologin()
                return
            } else {
                DispatchQueue.main.async {
                    AlertManager.showError("serverConnectError".localized, controller: self)
                    if !(self.navigationController?.topViewController?.isKind(of: LoginViewController.self))! {
                        self.performSegue(withIdentifier: Constants.Segue.splashToLogin, sender: nil)
                    }
                }
            }
        }
    }
    
    private func autologin() {
        AuthManager.validateAuth0Session(completion: { (succes, error) in
            if succes {
                DispatchQueue.main.async {
                    self.performSegue(withIdentifier: Constants.Segue.splashToMain, sender: nil)
                }
                
            } else {
                DispatchQueue.main.async {
                    if !(self.navigationController?.topViewController?.isKind(of: LoginViewController.self))! {
                        self.performSegue(withIdentifier: Constants.Segue.splashToLogin, sender: nil)
                    }
                }
            }
        })
    }
}
