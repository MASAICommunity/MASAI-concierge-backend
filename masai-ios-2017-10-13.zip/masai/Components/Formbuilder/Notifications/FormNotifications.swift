//
//  FormNotifications.swift
//  masai
//
//  Created by Florian Rath on 15.08.17.
//  Copyright © 2017 Codepool GmbH. All rights reserved.
//

import Foundation


struct FormNotifications {
    
    static let formValueChanged = NSNotification.Name("FormNotifications.formValueChanged")
    
}
