//
//  Form.swift
//  masai
//
//  Created by Florian Rath on 11.08.17.
//  Copyright © 2017 Codepool GmbH. All rights reserved.
//

import Foundation
import UIKit


class Form: FormType {
    
    // MARK: Properties
    
    var sections: [FormSectionType]
    
    
    // MARK: Lifecycle
    
    init() {
        self.sections = []
    }
    
    
    // MARK: Public
    
    func add(section: FormSectionType) {
        sections.append(section)
    }
    
    
    // MARK: View
    
    private var formView: FormView?
    
    func createView(forceRecreation: Bool = false) -> FormView {
        if let fv = formView,
            forceRecreation == false {
            return fv
        }
        
        formView = FormView(form: self)
        return formView!
    }
    
    
    // MARK: Form evaluation
    
    var values: FormDictionary {
        var dict: FormDictionary = [:]
        for section in sections {
            var existingSection = dict[section.header.identifier] ?? []
            existingSection.append(contentsOf: section.values)
            dict[section.header.identifier] = existingSection
        }
        return dict
    }
    
}
